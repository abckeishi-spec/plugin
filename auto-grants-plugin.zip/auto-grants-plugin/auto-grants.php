<?php
/**
 * Plugin Name: Auto Grants - 完全自動型補助金コンテンツ生成
 * Plugin URI: https://example.com/auto-grants
 * Description: JグランツAPIとAIを活用して、補助金情報を自動的に取得・記事生成・公開までを完全自動化
 * Version: 1.0.0
 * Author: 中澤圭志
 * Author URI: https://example.com
 * License: GPL v2 or later
 * Text Domain: auto-grants
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

// 直接アクセスを防止
if (!defined('ABSPATH')) {
    exit;
}

// プラグイン定数定義
define('AUTO_GRANTS_VERSION', '1.0.0');
define('AUTO_GRANTS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AUTO_GRANTS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AUTO_GRANTS_PLUGIN_FILE', __FILE__);
define('AUTO_GRANTS_LOG_DIR', AUTO_GRANTS_PLUGIN_DIR . 'logs/');
define('AUTO_GRANTS_POST_TYPE', 'grant');

/**
 * Auto Grants プラグイン メインクラス
 */
class Auto_Grants {

    /**
     * シングルトンインスタンス
     */
    private static $instance = null;

    /**
     * 各種マネージャークラス
     */
    private $api_manager;
    private $ai_manager;
    private $scheduler;
    private $admin_manager;

    /**
     * シングルトンインスタンス取得
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * コンストラクタ
     */
    private function __construct() {
        $this->init();
    }

    /**
     * 初期化処理
     */
    private function init() {
        // 必要ファイルの読み込み
        $this->includes();
        
        // フックの設定
        $this->hooks();
        
        // スケジューラーの初期化
        $this->init_scheduler();
    }

    /**
     * 必要ファイルの読み込み
     */
    private function includes() {
        require_once AUTO_GRANTS_PLUGIN_DIR . 'includes/class-auto-grants-api.php';
        require_once AUTO_GRANTS_PLUGIN_DIR . 'includes/class-auto-grants-ai.php';
        require_once AUTO_GRANTS_PLUGIN_DIR . 'includes/class-auto-grants-scheduler.php';
        require_once AUTO_GRANTS_PLUGIN_DIR . 'includes/class-auto-grants-admin.php';
        require_once AUTO_GRANTS_PLUGIN_DIR . 'includes/class-auto-grants-acf.php';
        require_once AUTO_GRANTS_PLUGIN_DIR . 'includes/auto-grants-functions.php';
    }

    /**
     * フックの設定
     */
    private function hooks() {
        // プラグイン有効化時
        register_activation_hook(__FILE__, array($this, 'activate'));
        
        // プラグイン無効化時
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // プラグイン初期化
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('init', array($this, 'register_post_type'));
        add_action('init', array($this, 'register_taxonomies'));
        
        // ACF連携
        if ($this->is_acf_active()) {
            add_action('init', array($this, 'register_acf_fields'));
        }
    }

    /**
     * スケジューラーの初期化
     */
    private function init_scheduler() {
        $this->scheduler = new Auto_Grants_Scheduler();
    }

    /**
     * プラグイン有効化
     */
    public function activate() {
        // ログディレクトリ作成
        if (!file_exists(AUTO_GRANTS_LOG_DIR)) {
            wp_mkdir_p(AUTO_GRANTS_LOG_DIR);
        }
        
        // デフォルト設定の保存
        $this->set_default_options();
        
        // カスタム投稿タイプ作成
        $this->register_post_type();
        $this->register_taxonomies();
        
        // スケジュールイベント設定
        if (!wp_next_scheduled('auto_grants_daily_sync')) {
            wp_schedule_event(time(), 'daily', 'auto_grants_daily_sync');
        }
        
        if (!wp_next_scheduled('auto_grants_ai_process')) {
            $frequency = get_option('auto_grants_ai_frequency', 'hourly');
            wp_schedule_event(time(), $frequency, 'auto_grants_ai_process');
        }
        
        // フラッシュ（パーマリンク設定）
        flush_rewrite_rules();
    }

    /**
     * プラグイン無効化
     */
    public function deactivate() {
        // スケジュールイベントの解除
        wp_clear_scheduled_hook('auto_grants_daily_sync');
        wp_clear_scheduled_hook('auto_grants_ai_process');
        
        // フラッシュ（パーマリンク設定）
        flush_rewrite_rules();
    }

    /**
     * デフォルトオプション設定
     */
    private function set_default_options() {
        $defaults = array(
            'auto_grants_api_endpoint' => 'https://api.jgrants-portal.go.jp/exp/v1/public',
            'auto_grants_sync_time' => '03:00',
            'auto_grants_ai_frequency' => 'hourly',
            'auto_grants_ai_prompt' => $this->get_default_ai_prompt(),
            'auto_grants_log_level' => 'info',
            'auto_grants_batch_size' => 10,
        );
        
        foreach ($defaults as $key => $value) {
            if (false === get_option($key)) {
                add_option($key, $value);
            }
        }
    }

    /**
     * デフォルトAIプロンプト取得
     */
    private function get_default_ai_prompt() {
        return 'あなたは補助金申請の専門家です。以下の補助金情報を基に、申請者にとって有益な記事を作成してください。

【記事作成ガイドライン】
1. タイトルはSEOを意識し、補助金名＋「申請方法」や「利用方法」などのキーワードを含める
2. 本文は以下の構成で書く：
   - この補助金とは（3行程度）
   - 対象者・条件
   - 支援内容（金額、期間など）
   - 申請方法と必要書類
   - 申請のポイントと注意事項
   - よくある質問
3. 専門用語は避け、初心者にも分かりやすい言葉で説明する
4. 申請締切が近い場合は、その旨を強調する
5. 3行要約は、箇条書きで記事の要点を整理する

【補助金情報】';
    }

    /**
     * 言語ファイル読み込み
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'auto-grants',
            false,
            dirname(plugin_basename(__FILE__)) . '/languages'
        );
    }

    /**
     * カスタム投稿タイプ登録
     */
    public function register_post_type() {
        $labels = array(
            'name'                  => _x('補助金', 'Post type general name', 'auto-grants'),
            'singular_name'         => _x('補助金', 'Post type singular name', 'auto-grants'),
            'menu_name'             => _x('補助金', 'Admin Menu text', 'auto-grants'),
            'name_admin_bar'        => _x('補助金', 'Add New on Toolbar', 'auto-grants'),
            'add_new'               => __('新規追加', 'auto-grants'),
            'add_new_item'          => __('新規補助金を追加', 'auto-grants'),
            'new_item'              => __('新規補助金', 'auto-grants'),
            'edit_item'             => __('補助金を編集', 'auto-grants'),
            'view_item'             => __('補助金を表示', 'auto-grants'),
            'all_items'             => __('すべての補助金', 'auto-grants'),
            'search_items'          => __('補助金を検索', 'auto-grants'),
            'parent_item_colon'     => __('親補助金:', 'auto-grants'),
            'not_found'             => __('補助金が見つかりませんでした。', 'auto-grants'),
            'not_found_in_trash'    => __('ゴミ箱内に補助金が見つかりませんでした。', 'auto-grants'),
            'featured_image'        => _x('補助金アイキャッチ画像', 'Overrides the "Featured Image" phrase', 'auto-grants'),
            'set_featured_image'    => _x('アイキャッチ画像を設定', 'Overrides the "Set featured image" phrase', 'auto-grants'),
            'remove_featured_image' => _x('アイキャッチ画像を削除', 'Overrides the "Remove featured image" phrase', 'auto-grants'),
            'use_featured_image'    => _x('アイキャッチ画像として使用', 'Overrides the "Use as featured image" phrase', 'auto-grants'),
            'archives'              => _x('補助金アーカイブ', 'The post type archive label', 'auto-grants'),
            'insert_into_item'      => _x('補助金に挿入', 'Overrides the "Insert into post" phrase', 'auto-grants'),
            'uploaded_to_this_item' => _x('この補助金にアップロード済み', 'Overrides the "Uploaded to this post" phrase', 'auto-grants'),
            'filter_items_list'     => _x('補助金リストをフィルター', 'Screen reader text', 'auto-grants'),
            'items_list_navigation' => _x('補助金リストナビゲーション', 'Screen reader text', 'auto-grants'),
            'items_list'            => _x('補助金リスト', 'Screen reader text', 'auto-grants'),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array('slug' => 'grant', 'with_front' => false),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 5,
            'menu_icon'          => 'dashicons-money-alt',
            'supports'           => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments', 'custom-fields'),
            'show_in_rest'       => true,
            'rest_base'          => 'grants',
            'rest_controller_class' => 'WP_REST_Posts_Controller',
        );

        register_post_type(AUTO_GRANTS_POST_TYPE, $args);
    }

    /**
     * カスタム分類法登録
     */
    public function register_taxonomies() {
        // 補助金カテゴリー
        $labels = array(
            'name'              => _x('補助金カテゴリー', 'taxonomy general name', 'auto-grants'),
            'singular_name'     => _x('補助金カテゴリー', 'taxonomy singular name', 'auto-grants'),
            'search_items'      => __('補助金カテゴリーを検索', 'auto-grants'),
            'all_items'         => __('すべてのカテゴリー', 'auto-grants'),
            'parent_item'       => __('親カテゴリー', 'auto-grants'),
            'parent_item_colon' => __('親カテゴリー:', 'auto-grants'),
            'edit_item'         => __('カテゴリーを編集', 'auto-grants'),
            'update_item'       => __('カテゴリーを更新', 'auto-grants'),
            'add_new_item'      => __('新規カテゴリーを追加', 'auto-grants'),
            'new_item_name'     => __('新規カテゴリー名', 'auto-grants'),
            'menu_name'         => __('カテゴリー', 'auto-grants'),
        );

        $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array('slug' => 'grant-category'),
            'show_in_rest'      => true,
        );

        register_taxonomy('grant_category', array(AUTO_GRANTS_POST_TYPE), $args);

        // 申請難易度
        $labels = array(
            'name'              => _x('申請難易度', 'taxonomy general name', 'auto-grants'),
            'singular_name'     => _x('申請難易度', 'taxonomy singular name', 'auto-grants'),
            'search_items'      => __('申請難易度を検索', 'auto-grants'),
            'all_items'         => __('すべての難易度', 'auto-grants'),
            'edit_item'         => __('難易度を編集', 'auto-grants'),
            'update_item'       => __('難易度を更新', 'auto-grants'),
            'add_new_item'      => __('新規難易度を追加', 'auto-grants'),
            'new_item_name'     => __('新規難易度', 'auto-grants'),
            'menu_name'         => __('難易度', 'auto-grants'),
        );

        $args = array(
            'hierarchical'      => false,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array('slug' => 'grant-difficulty'),
            'show_in_rest'      => true,
        );

        register_taxonomy('grant_difficulty', array(AUTO_GRANTS_POST_TYPE), $args);
    }

    /**
     * ACFフィールド登録
     */
    public function register_acf_fields() {
        if (function_exists('acf_add_local_field_group')) {
            new Auto_Grants_ACF();
        }
    }

    /**
     * ACFが有効かチェック
     */
    public function is_acf_active() {
        return class_exists('acf');
    }

    /**
     * APIマネージャー取得
     */
    public function get_api_manager() {
        if (null === $this->api_manager) {
            $this->api_manager = new Auto_Grants_API();
        }
        return $this->api_manager;
    }

    /**
     * AIマネージャー取得
     */
    public function get_ai_manager() {
        if (null === $this->ai_manager) {
            $this->ai_manager = new Auto_Grants_AI();
        }
        return $this->ai_manager;
    }

    /**
     * 管理画面マネージャー取得
     */
    public function get_admin_manager() {
        if (null === $this->admin_manager) {
            $this->admin_manager = new Auto_Grants_Admin();
        }
        return $this->admin_manager;
    }
}

/**
 * グローバル関数：メインインスタンス取得
 */
function auto_grants() {
    return Auto_Grants::get_instance();
}

// プラグイン初期化
auto_grants();