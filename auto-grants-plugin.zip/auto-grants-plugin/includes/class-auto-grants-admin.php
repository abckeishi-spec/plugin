<?php
/**
 * 管理画面クラス
 * 
 * @package Auto_Grants
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Auto_Grants_Admin クラス
 */
class Auto_Grants_Admin {

    /**
     * メニュースラッグ
     */
    const MENU_SLUG = 'auto-grants-settings';

    /**
     * 設定グループ
     */
    const SETTINGS_GROUP = 'auto_grants_settings';

    /**
     * コンストラクタ
     */
    public function __construct() {
        $this->init_hooks();
    }

    /**
     * フックの初期化
     */
    private function init_hooks() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('admin_notices', array($this, 'admin_notices'));
        
        // カスタム投稿タイプのカラム管理
        add_filter('manage_' . AUTO_GRANTS_POST_TYPE . '_posts_columns', array($this, 'add_custom_columns'));
        add_action('manage_' . AUTO_GRANTS_POST_TYPE . '_posts_custom_column', array($this, 'render_custom_columns'), 10, 2);
        
        // 一括操作
        add_action('admin_action_auto_grants_bulk_import', array($this, 'bulk_import'));
        add_action('admin_action_auto_grants_bulk_ai', array($this, 'bulk_ai_process'));
    }

    /**
     * 管理メニュー追加
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Auto Grants 設定', 'auto-grants'),
            __('Auto Grants', 'auto-grants'),
            'manage_options',
            self::MENU_SLUG,
            array($this, 'render_settings_page'),
            'dashicons-money-alt',
            30
        );

        add_submenu_page(
            self::MENU_SLUG,
            __('設定', 'auto-grants'),
            __('設定', 'auto-grants'),
            'manage_options',
            self::MENU_SLUG,
            array($this, 'render_settings_page')
        );

        add_submenu_page(
            self::MENU_SLUG,
            __('手動実行', 'auto-grants'),
            __('手動実行', 'auto-grants'),
            'manage_options',
            'auto-grants-manual',
            array($this, 'render_manual_page')
        );

        add_submenu_page(
            self::MENU_SLUG,
            __('ログ', 'auto-grants'),
            __('ログ', 'auto-grants'),
            'manage_options',
            'auto-grants-logs',
            array($this, 'render_logs_page')
        );
    }

    /**
     * 管理画面スクリプト読み込み
     *
     * @param string $hook_suffix フックサフィックス
     */
    public function enqueue_admin_scripts($hook_suffix) {
        if (strpos($hook_suffix, 'auto-grants') === false) {
            return;
        }

        wp_enqueue_script(
            'auto-grants-admin',
            AUTO_GRANTS_PLUGIN_URL . 'assets/admin.js',
            array('jquery'),
            AUTO_GRANTS_VERSION,
            true
        );

        wp_localize_script('auto-grants-admin', 'auto_grants_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => array(
                'manual_sync' => wp_create_nonce('auto_grants_manual_sync'),
                'manual_ai'   => wp_create_nonce('auto_grants_manual_ai'),
            ),
        ));

        wp_enqueue_style(
            'auto-grants-admin',
            AUTO_GRANTS_PLUGIN_URL . 'assets/admin.css',
            array(),
            AUTO_GRANTS_VERSION
        );
    }

    /**
     * 設定登録
     */
    public function register_settings() {
        // API設定
        register_setting(self::SETTINGS_GROUP, 'auto_grants_api_endpoint');
        register_setting(self::SETTINGS_GROUP, 'auto_grants_gemini_api_key');

        // 同期設定
        register_setting(self::SETTINGS_GROUP, 'auto_grants_sync_time');
        register_setting(self::SETTINGS_GROUP, 'auto_grants_ai_frequency');
        register_setting(self::SETTINGS_GROUP, 'auto_grants_batch_size');

        // AI設定
        register_setting(self::SETTINGS_GROUP, 'auto_grants_ai_prompt');

        // ログ設定
        register_setting(self::SETTINGS_GROUP, 'auto_grants_log_level');

        // 設定セクション
        add_settings_section(
            'auto_grants_api_section',
            __('API設定', 'auto-grants'),
            array($this, 'api_section_callback'),
            self::MENU_SLUG
        );

        add_settings_section(
            'auto_grants_sync_section',
            __('同期設定', 'auto-grants'),
            array($this, 'sync_section_callback'),
            self::MENU_SLUG
        );

        add_settings_section(
            'auto_grants_ai_section',
            __('AI設定', 'auto-grants'),
            array($this, 'ai_section_callback'),
            self::MENU_SLUG
        );

        add_settings_section(
            'auto_grants_log_section',
            __('ログ設定', 'auto-grants'),
            array($this, 'log_section_callback'),
            self::MENU_SLUG
        );

        // API設定フィールド
        add_settings_field(
            'auto_grants_api_endpoint',
            __('JグランツAPIエンドポイント', 'auto-grants'),
            array($this, 'render_text_field'),
            self::MENU_SLUG,
            'auto_grants_api_section',
            array(
                'label_for' => 'auto_grants_api_endpoint',
                'default'   => 'https://api.jgrants-portal.go.jp/exp/v1/public',
                'desc'      => __('JグランツAPIのベースURLを設定してください。', 'auto-grants'),
            )
        );

        add_settings_field(
            'auto_grants_gemini_api_key',
            __('Gemini APIキー', 'auto-grants'),
            array($this, 'render_password_field'),
            self::MENU_SLUG,
            'auto_grants_api_section',
            array(
                'label_for' => 'auto_grants_gemini_api_key',
                'desc'      => __('Google AI Studioから取得したGemini APIキーを設定してください。', 'auto-grants'),
            )
        );

        // 同期設定フィールド
        add_settings_field(
            'auto_grants_sync_time',
            __('自動同期時刻', 'auto-grants'),
            array($this, 'render_time_field'),
            self::MENU_SLUG,
            'auto_grants_sync_section',
            array(
                'label_for' => 'auto_grants_sync_time',
                'default'   => '03:00',
                'desc'      => __('毎日自動で補助金情報を取得する時刻を設定してください。', 'auto-grants'),
            )
        );

        add_settings_field(
            'auto_grants_ai_frequency',
            __('AI処理頻度', 'auto-grants'),
            array($this, 'render_select_field'),
            self::MENU_SLUG,
            'auto_grants_sync_section',
            array(
                'label_for' => 'auto_grants_ai_frequency',
                'options'   => array(
                    'every_30_minutes' => __('30分ごと', 'auto-grants'),
                    'hourly'           => __('1時間ごと', 'auto-grants'),
                    'every_2_hours'    => __('2時間ごと', 'auto-grants'),
                    'every_3_hours'    => __('3時間ごと', 'auto-grants'),
                    'every_6_hours'    => __('6時間ごと', 'auto-grants'),
                    'every_12_hours'   => __('12時間ごと', 'auto-grants'),
                    'daily'            => __('1日1回', 'auto-grants'),
                ),
                'default'   => 'hourly',
                'desc'      => __('AIによる記事生成・公開の頻度を設定してください。', 'auto-grants'),
            )
        );

        add_settings_field(
            'auto_grants_batch_size',
            __('一括処理件数', 'auto-grants'),
            array($this, 'render_number_field'),
            self::MENU_SLUG,
            'auto_grants_sync_section',
            array(
                'label_for' => 'auto_grants_batch_size',
                'default'   => 5,
                'min'       => 1,
                'max'       => 50,
                'desc'      => __('一度に処理する投稿の件数を設定してください。', 'auto-grants'),
            )
        );

        // AI設定フィールド
        add_settings_field(
            'auto_grants_ai_prompt',
            __('AIプロンプト', 'auto-grants'),
            array($this, 'render_textarea_field'),
            self::MENU_SLUG,
            'auto_grants_ai_section',
            array(
                'label_for' => 'auto_grants_ai_prompt',
                'default'   => $this->get_default_ai_prompt(),
                'rows'    => 10,
                'desc'    => __('AIに与える指示（プロンプト）を設定してください。', 'auto-grants'),
            )
        );

        // ログ設定フィールド
        add_settings_field(
            'auto_grants_log_level',
            __('ログレベル', 'auto-grants'),
            array($this, 'render_select_field'),
            self::MENU_SLUG,
            'auto_grants_log_section',
            array(
                'label_for' => 'auto_grants_log_level',
                'options'   => array(
                    'none'    => __('無効', 'auto-grants'),
                    'error'   => __('エラーのみ', 'auto-grants'),
                    'warning' => __('警告以上', 'auto-grants'),
                    'info'    => __('情報以上', 'auto-grants'),
                    'debug'   => __('デバッグ', 'auto-grants'),
                ),
                'default'   => 'info',
                'desc'      => __('ログの詳細度を設定してください。', 'auto-grants'),
            )
        );
    }

    /**
     * 設定ページレンダリング
     */
    public function render_settings_page() {
        ?>
        <div class="wrap" id="auto-grants-settings">
            <h1 class="wp-heading-inline"><?php echo esc_html(get_admin_page_title()); ?></h1>

            <form method="post" action="options.php">
                <?php
                settings_fields(self::SETTINGS_GROUP);
                do_settings_sections(self::MENU_SLUG);
                submit_button();
                ?>
            </form>
</div>
        <?php
    }

    /**
     * 手動実行ページレンダリング
     */
    public function render_manual_page() {
        ?>
        <div class="wrap" id="auto-grants-manual">
            <h1 class="wp-heading-inline"><?php echo esc_html(get_admin_page_title()); ?></h1>

            <div class="auto-grants-manual-section">
                <h2><?php _e('補助金情報同期', 'auto-grants'); ?></h2>
                <p><?php _e('JグランツAPIから最新の補助金情報を手動で取得します。', 'auto-grants'); ?></p>
                <button type="button" id="manual-sync" class="button button-primary">
                    <?php _e('今すぐ同期', 'auto-grants'); ?>
                </button>
                <span id="sync-result" class="result-message"></span>
            </div>

            <div class="auto-grants-manual-section">
                <h2><?php _e('AI記事生成', 'auto-grants'); ?></h2>
                <p><?php _e('下書き状態の補助金情報をAIで記事化して公開します。', 'auto-grants'); ?></p>
                <div class="batch-size-control">
                    <label for="batch-size"><?php _e('処理件数:', 'auto-grants'); ?></label>
                    <select id="batch-size">
                        <option value="1">1件</option>
                        <option value="3" selected>3件</option>
                        <option value="5">5件</option>
                        <option value="10">10件</option>
                    </select>
                </div>
                <button type="button" id="manual-ai" class="button button-primary">
                    <?php _e('AI処理実行', 'auto-grants'); ?>
                </button>
                <span id="ai-result" class="result-message"></span>
            </div>

            <div class="auto-grants-status">
                <h2><?php _e('ステータス', 'auto-grants'); ?></h2>
                <div class="status-item">
                    <strong><?php _e('次回同期予定:', 'auto-grants'); ?></strong>
                    <span id="next-sync"><?php echo esc_html($this->get_next_sync_time()); ?></span>
                </div>
                <div class="status-item">
                    <strong><?php _e('次回AI処理予定:', 'auto-grants'); ?></strong>
                    <span id="next-ai"><?php echo esc_html($this->get_next_ai_time()); ?></span>
                </div>
                <div class="status-item">
                    <strong><?php _e('未処理下書き数:', 'auto-grants'); ?></strong>
                    <span id="draft-count"><?php echo esc_html($this->get_draft_count()); ?></span>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * ログページレンダリング
     */
    public function render_logs_page() {
        $logs = $this->get_recent_logs();
        ?>
        <div class="wrap" id="auto-grants-logs">
            <h1 class="wp-heading-inline"><?php echo esc_html(get_admin_page_title()); ?></h1>

            <div class="auto-grants-log-controls">
                <button type="button" id="refresh-logs" class="button">
                    <?php _e('ログ更新', 'auto-grants'); ?>
                </button>
                <button type="button" id="clear-logs" class="button button-link-delete">
                    <?php _e('ログクリア', 'auto-grants'); ?>
                </button>
            </div>

            <div id="log-container">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th scope="col" class="manage-column column-datetime"><?php _e('日時', 'auto-grants'); ?></th>
                            <th scope="col" class="manage-column column-level"><?php _e('レベル', 'auto-grants'); ?></th>
                            <th scope="col" class="manage-column column-message"><?php _e('メッセージ', 'auto-grants'); ?></th>
                            <th scope="col" class="manage-column column-context"><?php _e('コンテキスト', 'auto-grants'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($logs)): ?>
                            <tr>
                                <td colspan="4"><?php _e('ログが見つかりません。', 'auto-grants'); ?></td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td><?php echo esc_html($log['datetime']); ?></td>
                                    <td><span class="log-level log-level-"><?php echo esc_html($log['level']); ?></span></td>
                                    <td><?php echo esc_html($log['message']); ?></td>
                                    <td><?php echo !empty($log['context']) ? esc_html(json_encode($log['context'])) : ''; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    /**
     * テキストフィールドレンダリング
     */
    public function render_text_field($args) {
        $option = get_option($args['label_for'], $args['default'] ?? '');
        ?>
        <input type="text" 
               id="<?php echo esc_attr($args['label_for']); ?>"
               name="<?php echo esc_attr($args['label_for']); ?>"
               value="<?php echo esc_attr($option); ?>"
               class="regular-text"
               <?php echo isset($args['required']) && $args['required'] ? 'required' : ''; ?> >
        <?php if (isset($args['desc'])): ?>
            <p class="description"><?php echo esc_html($args['desc']); ?></p>
        <?php endif; ?>
        <?php
    }

    /**
     * パスワードフィールドレンダリング
     */
    public function render_password_field($args) {
        $option = get_option($args['label_for']);
        ?>
        <input type="password" 
               id="<?php echo esc_attr($args['label_for']); ?>"
               name="<?php echo esc_attr($args['label_for']); ?>"
               value="<?php echo esc_attr($option); ?>"
               class="regular-text"
               <?php echo isset($args['required']) && $args['required'] ? 'required' : ''; ?> >
        <?php if (isset($args['desc'])): ?>
            <p class="description"><?php echo esc_html($args['desc']); ?></p>
        <?php endif; ?>
        <?php
    }

    /**
     * テキストエリアフィールドレンダリング
     */
    public function render_textarea_field($args) {
        $option = get_option($args['label_for'], $args['default'] ?? '');
        $rows = $args['rows'] ?? 5;
        ?>
        <textarea id="<?php echo esc_attr($args['label_for']); ?>"
                  name="<?php echo esc_attr($args['label_for']); ?>"
                  rows="<?php echo esc_attr($rows); ?>"
                  class="large-text code"><?php echo esc_textarea($option); ?></textarea>
        <?php if (isset($args['desc'])): ?>
            <p class="description"><?php echo esc_html($args['desc']); ?></p>
        <?php endif; ?>
        <?php
    }

    /**
     * 数値フィールドレンダリング
     */
    public function render_number_field($args) {
        $option = get_option($args['label_for'], $args['default'] ?? '');
        $min = $args['min'] ?? 0;
        $max = $args['max'] ?? 999;
        ?>
        <input type="number" 
               id="<?php echo esc_attr($args['label_for']); ?>"
               name="<?php echo esc_attr($args['label_for']); ?>"
               value="<?php echo esc_attr($option); ?>"
               min="<?php echo esc_attr($min); ?>"
               max="<?php echo esc_attr($max); ?>"
               <?php echo isset($args['required']) && $args['required'] ? 'required' : ''; ?> >
        <?php if (isset($args['desc'])): ?>
            <p class="description"><?php echo esc_html($args['desc']); ?></p>
        <?php endif; ?>
        <?php
    }

    /**
     * 時間フィールドレンダリング
     */
    public function render_time_field($args) {
        $option = get_option($args['label_for'], $args['default'] ?? '');
        ?>
        <input type="time" 
               id="<?php echo esc_attr($args['label_for']); ?>"
               name="<?php echo esc_attr($args['label_for']); ?>"
               value="<?php echo esc_attr($option); ?>"
               <?php echo isset($args['required']) && $args['required'] ? 'required' : ''; ?> >
        <?php if (isset($args['desc'])): ?>
            <p class="description"><?php echo esc_html($args['desc']); ?></p>
        <?php endif; ?>
        <?php
    }

    /**
     * セレクトフィールドレンダリング
     */
    public function render_select_field($args) {
        $option = get_option($args['label_for'], $args['default'] ?? '');
        ?>
        <select id="<?php echo esc_attr($args['label_for']); ?>" name="<?php echo esc_attr($args['label_for']); ?>">
            <?php foreach ($args['options'] as $value => $label): ?>
                <option value="<?php echo esc_attr($value); ?>" <?php selected($option, $value); ?>>
                    <?php echo esc_html($label); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <?php if (isset($args['desc'])): ?>
            <p class="description"><?php echo esc_html($args['desc']); ?></p>
        <?php endif; ?>
        <?php
    }

    /**
     * セクションコールバック
     */
    public function api_section_callback() {
        echo '<p>' . __('JグランツAPIとGemini APIの設定を行います。', 'auto-grants') . '</p>';
    }

    public function sync_section_callback() {
        echo '<p>' . __('自動同期とAI処理のスケジュール設定を行います。', 'auto-grants') . '</p>';
    }

    public function ai_section_callback() {
        echo '<p>' . __('AIによる記事生成の設定を行います。', 'auto-grants') . '</p>';
    }

    public function log_section_callback() {
        echo '<p>' . __('ログ出力の設定を行います。', 'auto-grants') . '</p>';
    }

    /**
     * カスタムカラム追加
     */
    public function add_custom_columns($columns) {
        $new_columns = array(
            'cb'              => $columns['cb'],
            'title'           => $columns['title'],
            'grant_status'    => __('ステータス', 'auto-grants'),
            'grant_category'  => __('カテゴリー', 'auto-grants'),
            'grant_difficulty' => __('難易度', 'auto-grants'),
            'ai_processed'    => __('AI処理', 'auto-grants'),
            'max_amount'      => __('最大支援額', 'auto-grants'),
            'deadline'        => __('締切', 'auto-grants'),
            'date'            => $columns['date'],
        );

        return $new_columns;
    }

    /**
     * カスタムカラムレンダリング
     */
    public function render_custom_columns($column, $post_id) {
        switch ($column) {
            case 'grant_status':
                $status = get_post_meta($post_id, 'application_status', true);
                $status_labels = array(
                    'open'     => '募集中',
                    'closed'   => '募集終了',
                    'upcoming' => '募集開始前',
                );
                echo esc_html($status_labels[$status] ?? '不明');
                break;

            case 'grant_category':
                $terms = get_the_terms($post_id, 'grant_category');
                if ($terms && !is_wp_error($terms)) {
                    $categories = array();
                    foreach ($terms as $term) {
                        $categories[] = $term->name;
                    }
                    echo esc_html(implode(', ', $categories));
                } else {
                    echo '—';
                }
                break;

            case 'grant_difficulty':
                $terms = get_the_terms($post_id, 'grant_difficulty');
                if ($terms && !is_wp_error($terms)) {
                    $difficulties = array();
                    foreach ($terms as $term) {
                        $difficulties[] = $term->name;
                    }
                    echo esc_html(implode(', ', $difficulties));
                } else {
                    echo '—';
                }
                break;

            case 'ai_processed':
                $processed = get_post_meta($post_id, 'ai_processed', true);
                echo $processed === '1' ? '✅ 完了' : '⏳ 未処理';
                break;

            case 'max_amount':
                $amount = get_post_meta($post_id, 'max_amount', true);
                echo esc_html($amount ?: '—');
                break;

            case 'deadline':
                $deadline = get_post_meta($post_id, 'deadline_text', true);
                echo esc_html($deadline ?: '—');
                break;
        }
    }

    /**
     * デフォルトAIプロンプト取得
     */
    private function get_default_ai_prompt() {
        return 'あなたは補助金申請の専門家です。以下の補助金情報を基に、申請者にとって有益な記事を作成してください。

【記事作成ガイドライン】
1. タイトルはSEOを意識し、補助金名＋「申請方法」や「利用方法」などのキーワードを含める
2. 本文は以下の構成で書く：
   - この補助金とは（3行程度）
   - 対象者・条件
   - 支援内容（金額、期間など）
   - 申請方法と必要書類
   - 申請のポイントと注意事項
   - よくある質問
3. 専門用語は避け、初心者にも分かりやすい言葉で説明する
4. 申請締切が近い場合は、その旨を強調する
5. 3行要約は、箇条書きで記事の要点を整理する

【補助金情報】';
    }

    /**
     * 次回同期時刻取得
     */
    private function get_next_sync_time() {
        $scheduler = auto_grants()->scheduler;
        return $scheduler->get_next_scheduled_time('auto_grants_daily_sync');
    }

    /**
     * 次回AI時刻取得
     */
    private function get_next_ai_time() {
        $scheduler = auto_grants()->scheduler;
        return $scheduler->get_next_scheduled_time('auto_grants_ai_process');
    }

    /**
     * 下書き数取得
     */
    private function get_draft_count() {
        $args = array(
            'post_type'      => AUTO_GRANTS_POST_TYPE,
            'post_status'    => 'draft',
            'posts_per_page' => -1,
            'meta_query'     => array(
                'relation' => 'OR',
                array(
                    'key'     => 'ai_processed',
                    'compare' => 'NOT EXISTS',
                ),
                array(
                    'key'     => 'ai_processed',
                    'value'   => '1',
                    'compare' => '!=',
                ),
            ),
            'fields' => 'ids',
        );

        $posts = get_posts($args);
        return count($posts);
    }

    /**
     * 最近のログ取得
     */
    private function get_recent_logs($limit = 100) {
        $log_file = AUTO_GRANTS_LOG_DIR . 'auto-grants.log';
        
        if (!file_exists($log_file)) {
            return array();
        }

        $logs = array();
        $lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        
        if ($lines === false) {
            return array();
        }

        // 最新のログから指定件数取得
        $lines = array_slice($lines, -$limit);
        
        foreach ($lines as $line) {
            $log = json_decode($line, true);
            if ($log && isset($log['datetime'], $log['level'], $log['message'])) {
                $logs[] = $log;
            }
        }

        return array_reverse($logs); // 新しい順にする
    }

    /**
     * 管理画面通知
     */
    public function admin_notices() {
        // Gemini APIキー未設定警告
        $gemini_key = get_option('auto_grants_gemini_api_key');
        if (empty($gemini_key) && isset($_GET['page']) && $_GET['page'] === self::MENU_SLUG) {
            ?>
            <div class="notice notice-warning is-dismissible">
                <p><?php _e('Auto Grants: Gemini APIキーが設定されていません。AIによる記事生成を利用するには設定が必要です。', 'auto-grants'); ?></p>
            </div>
            <?php
        }

        // 同期エラー通知
        $last_sync_error = get_option('auto_grants_last_sync_error');
        if (!empty($last_sync_error) && time() - strtotime($last_sync_error) < 86400) {
            ?>
            <div class="notice notice-error is-dismissible">
                <p><?php _e('Auto Grants: 最新の補助金情報同期でエラーが発生しました。ログを確認してください。', 'auto-grants'); ?></p>
            </div>
            <?php
        }
    }

    /**
     * 一括インポート
     */
    public function bulk_import() {
        // 権限チェック
        if (!current_user_can('manage_options')) {
            wp_die('権限がありません。');
        }

        // ノンスチェック
        check_admin_referer('auto_grants_bulk_import');

        $keyword = isset($_POST['import_keyword']) ? sanitize_text_field($_POST['import_keyword']) : '';
        $limit = isset($_POST['import_limit']) ? intval($_POST['import_limit']) : 10;

        if (empty($keyword)) {
            wp_redirect(add_query_arg(array('import_error' => 'no_keyword'), wp_get_referer()));
            exit;
        }

        $api = auto_grants()->get_api_manager();
        $grants = $api->search_grants($keyword, $limit);

        if (is_wp_error($grants)) {
            wp_redirect(add_query_arg(array('import_error' => $grants->get_error_code()), wp_get_referer()));
            exit;
        }

        $imported = 0;
        foreach ($grants as $grant) {
            if (isset($grant['id'])) {
                $detail = $api->fetch_grant_detail($grant['id']);
                if (!is_wp_error($detail)) {
                    $post_data = $api->convert_to_post_data($detail);
                    $post_id = wp_insert_post($post_data);
                    if (!is_wp_error($post_id)) {
                        $imported++;
                    }
                }
            }
        }

        wp_redirect(add_query_arg(array('imported' => $imported), wp_get_referer()));
        exit;
    }

    /**
     * 一括AI処理
     */
    public function bulk_ai_process() {
        // 権限チェック
        if (!current_user_can('manage_options')) {
            wp_die('権限がありません。');
        }

        // ノンスチェック
        check_admin_referer('auto_grants_bulk_ai');

        $ai_manager = auto_grants()->get_ai_manager();
        $batch_size = isset($_POST['ai_batch_size']) ? intval($_POST['ai_batch_size']) : 5;
        
        $result = $ai_manager->process_posts_batch($batch_size);

        if (is_wp_error($result)) {
            wp_redirect(add_query_arg(array('ai_error' => $result->get_error_code()), wp_get_referer()));
            exit;
        }

        wp_redirect(add_query_arg(array(
            'ai_processed' => $result['processed'],
            'ai_errors'    => $result['errors'],
        ), wp_get_referer()));
        exit;
    }
}