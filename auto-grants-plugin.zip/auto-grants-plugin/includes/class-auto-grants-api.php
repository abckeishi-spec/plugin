<?php
/**
 * JグランツAPI連携クラス
 * 
 * @package Auto_Grants
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Auto_Grants_API クラス
 */
class Auto_Grants_API {

    /**
     * APIベースURL
     */
    private $api_base_url;

    /**
     * リトライ回数
     */
    private $max_retries = 3;

    /**
     * タイムアウト（秒）
     */
    private $timeout = 30;

    /**
     * コンストラクタ
     */
    public function __construct() {
        $this->api_base_url = get_option('auto_grants_api_endpoint', 'https://api.jgrants-portal.go.jp/exp/v1/public');
    }

    /**
     * 補助金一覧を取得
     *
     * @param array $args 検索パラメータ
     * @return array|WP_Error 補助金一覧またはエラー
     */
    public function fetch_grants_list($args = array()) {
        $defaults = array(
            'keyword' => '',
            'sort' => 'created_date',
            'order' => 'DESC',
            'acceptance' => '1',
            'use_purpose' => '',
            'industry' => '',
            'target_number_of_employees' => '',
            'target_area_search' => '',
            'page' => 1,
            'per_page' => 100,
        );

        $args = wp_parse_args($args, $defaults);

        // クエリパラメータの構築
        $query_params = array(
            'keyword' => $args['keyword'],
            'sort' => $args['sort'],
            'order' => $args['order'],
            'acceptance' => $args['acceptance'],
        );

        // オプションパラメータの追加
        if (!empty($args['use_purpose'])) {
            $query_params['use_purpose'] = $args['use_purpose'];
        }
        if (!empty($args['industry'])) {
            $query_params['industry'] = $args['industry'];
        }
        if (!empty($args['target_number_of_employees'])) {
            $query_params['target_number_of_employees'] = $args['target_number_of_employees'];
        }
        if (!empty($args['target_area_search'])) {
            $query_params['target_area_search'] = $args['target_area_search'];
        }

        $url = $this->api_base_url . '/subsidies';
        
        $this->log('info', '補助金一覧取得開始', array('url' => $url, 'params' => $query_params));

        $response = $this->make_request($url, 'GET', $query_params);

        if (is_wp_error($response)) {
            $this->log('error', '補助金一覧取得エラー', array('error' => $response->get_error_message()));
            return $response;
        }

        $grants = array();
        if (isset($response['result']) && is_array($response['result'])) {
            $grants = $response['result'];
            $this->log('info', '補助金一覧取得成功', array('count' => count($grants)));
        }

        return $grants;
    }

    /**
     * 補助金詳細を取得
     *
     * @param string $grant_id 補助金ID
     * @return array|WP_Error 補助金詳細またはエラー
     */
    public function fetch_grant_detail($grant_id) {
        if (empty($grant_id)) {
            return new WP_Error('invalid_grant_id', '補助金IDが指定されていません。');
        }

        $url = $this->api_base_url . '/subsidies/id/' . urlencode($grant_id);
        
        $this->log('info', '補助金詳細取得開始', array('grant_id' => $grant_id, 'url' => $url));

        $response = $this->make_request($url, 'GET');

        if (is_wp_error($response)) {
            $this->log('error', '補助金詳細取得エラー', array('grant_id' => $grant_id, 'error' => $response->get_error_message()));
            return $response;
        }

        if (isset($response['result']) && is_array($response['result']) && !empty($response['result'])) {
            $detail = $response['result'][0];
            $this->log('info', '補助金詳細取得成功', array('grant_id' => $grant_id));
            return $detail;
        }

        return new WP_Error('no_grant_data', '補助金データが見つかりませんでした。');
    }

    /**
     * 新規補助金を取得（差分同期用）
     *
     * @param string $last_sync_date 最終同期日時（Y-m-d H:i:s形式）
     * @return array|WP_Error 新規補助金一覧
     */
    public function fetch_new_grants($last_sync_date = null) {
        if (empty($last_sync_date)) {
            $last_sync_date = date('Y-m-d H:i:s', strtotime('-1 day'));
        }

        $args = array(
            'sort' => 'created_date',
            'order' => 'DESC',
            'acceptance' => '1',
        );

        // 最終同期日以降に作成された補助金を取得
        $grants = $this->fetch_grants_list($args);

        if (is_wp_error($grants)) {
            return $grants;
        }

        // 日時でフィルタリング
        $new_grants = array();
        $last_sync_timestamp = strtotime($last_sync_date);

        foreach ($grants as $grant) {
            if (isset($grant['acceptance_start_datetime'])) {
                $grant_timestamp = strtotime($grant['acceptance_start_datetime']);
                if ($grant_timestamp > $last_sync_timestamp) {
                    $new_grants[] = $grant;
                }
            }
        }

        $this->log('info', '新規補助金検索完了', array('total' => count($grants), 'new' => count($new_grants)));

        return $new_grants;
    }

    /**
     * 補助金を検索
     *
     * @param string $keyword 検索キーワード
     * @param int $limit 取得件数
     * @return array|WP_Error 検索結果
     */
    public function search_grants($keyword, $limit = 50) {
        $args = array(
            'keyword' => $keyword,
            'sort' => 'acceptance_end_datetime',
            'order' => 'ASC',
            'acceptance' => '1',
        );

        $grants = $this->fetch_grants_list($args);

        if (is_wp_error($grants)) {
            return $grants;
        }

        // 件数制限
        if (count($grants) > $limit) {
            $grants = array_slice($grants, 0, $limit);
        }

        $this->log('info', '補助金検索完了', array('keyword' => $keyword, 'count' => count($grants)));

        return $grants;
    }

    /**
     * APIリクエスト実行
     *
     * @param string $url リクエストURL
     * @param string $method HTTPメソッド
     * @param array $params クエリパラメータ
     * @return array|WP_Error レスポンスまたはエラー
     */
    private function make_request($url, $method = 'GET', $params = array()) {
        $retries = 0;
        
        while ($retries < $this->max_retries) {
            $args = array(
                'method'    => $method,
                'timeout'   => $this->timeout,
                'headers'   => array(
                    'Content-Type' => 'application/json',
                    'Accept'       => 'application/json',
                ),
            );

            if (!empty($params) && $method === 'GET') {
                $url = add_query_arg($params, $url);
            }

            $response = wp_remote_request($url, $args);

            if (is_wp_error($response)) {
                $retries++;
                $this->log('warning', 'APIリクエスト失敗（リトライ）', array('url' => $url, 'retry' => $retries, 'error' => $response->get_error_message()));
                continue;
            }

            $response_code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if ($response_code === 200) {
                return $data;
            } elseif ($response_code === 404) {
                return new WP_Error('not_found', '補助金が見つかりませんでした。', array('status' => 404));
            } elseif ($response_code === 429) {
                // レート制限対応
                $retry_after = isset($data['retry_after']) ? intval($data['retry_after']) : 60;
                $this->log('warning', 'レート制限検知', array('retry_after' => $retry_after));
                sleep($retry_after);
                $retries++;
                continue;
            } else {
                $error_message = isset($data['message']) ? $data['message'] : 'APIエラーが発生しました。';
                return new WP_Error('api_error', $error_message, array('status' => $response_code));
            }
        }

        return new WP_Error('max_retries_exceeded', '最大リトライ回数に達しました。');
    }

    /**
     * 補助金データをWordPress投稿データに変換
     *
     * @param array $grant_data 補助金データ
     * @return array WordPress投稿データ
     */
    public function convert_to_post_data($grant_data) {
        if (empty($grant_data)) {
            return array();
        }

        // 基本データ
        $post_data = array(
            'post_title'   => isset($grant_data['title']) ? sanitize_text_field($grant_data['title']) : '',
            'post_content' => isset($grant_data['detail']) ? wp_kses_post($grant_data['detail']) : '',
            'post_status'  => 'draft', // 初期状態は下書き
            'post_type'    => AUTO_GRANTS_POST_TYPE,
            'meta_input'   => array(),
        );

        // カスタムフィールドデータ
        $meta_fields = array(
            'official_id'               => isset($grant_data['id']) ? sanitize_text_field($grant_data['id']) : '',
            'name'                      => isset($grant_data['name']) ? sanitize_text_field($grant_data['name']) : '',
            'catch_phrase'              => isset($grant_data['subsidy_catch_phrase']) ? sanitize_text_field($grant_data['subsidy_catch_phrase']) : '',
            'use_purpose'               => isset($grant_data['use_purpose']) ? sanitize_text_field($grant_data['use_purpose']) : '',
            'industry'                  => isset($grant_data['industry']) ? sanitize_text_field($grant_data['industry']) : '',
            'target_area_search'        => isset($grant_data['target_area_search']) ? sanitize_text_field($grant_data['target_area_search']) : '',
            'target_area_detail'        => isset($grant_data['target_area_detail']) ? sanitize_text_field($grant_data['target_area_detail']) : '',
            'target_number_of_employees'  => isset($grant_data['target_number_of_employees']) ? sanitize_text_field($grant_data['target_number_of_employees']) : '',
            'subsidy_rate'              => isset($grant_data['subsidy_rate']) ? sanitize_text_field($grant_data['subsidy_rate']) : '',
            'max_amount_numeric'        => isset($grant_data['subsidy_max_limit']) ? intval($grant_data['subsidy_max_limit']) : 0,
            'acceptance_start_datetime'   => isset($grant_data['acceptance_start_datetime']) ? sanitize_text_field($grant_data['acceptance_start_datetime']) : '',
            'acceptance_end_datetime'   => isset($grant_data['acceptance_end_datetime']) ? sanitize_text_field($grant_data['acceptance_end_datetime']) : '',
            'official_url'              => isset($grant_data['front_subsidy_detail_page_url']) ? esc_url_raw($grant_data['front_subsidy_detail_page_url']) : '',
            'organization'              => isset($grant_data['support_organization']) ? sanitize_text_field($grant_data['support_organization']) : '',
            'raw_data'                  => wp_json_encode($grant_data),
        );

        // 最大金額の表示用テキストを生成
        if (isset($grant_data['subsidy_max_limit']) && $grant_data['subsidy_max_limit'] > 0) {
            $meta_fields['max_amount'] = number_format($grant_data['subsidy_max_limit']) . '円';
        } else {
            $meta_fields['max_amount'] = '情報なし';
        }

        // 締切日の処理
        if (isset($grant_data['acceptance_end_datetime'])) {
            $end_date = strtotime($grant_data['acceptance_end_datetime']);
            if ($end_date !== false) {
                $meta_fields['deadline_date'] = date('Ymd', $end_date);
                $meta_fields['deadline_text'] = date('Y年m月d日', $end_date);
                
                // ステータス判定
                if ($end_date < time()) {
                    $meta_fields['application_status'] = 'closed';
                } else {
                    $meta_fields['application_status'] = 'open';
                }
            }
        }

        // 申請難易度の初期値
        $meta_fields['difficulty_level'] = 'medium';

        $post_data['meta_input'] = $meta_fields;

        return $post_data;
    }

    /**
     * 補助金が既に存在するかチェック
     *
     * @param string $grant_id 補助金ID
     * @return int|null 既存投稿IDまたはnull
     */
    public function grant_exists($grant_id) {
        if (empty($grant_id)) {
            return null;
        }

        $args = array(
            'post_type'      => AUTO_GRANTS_POST_TYPE,
            'post_status'    => array('publish', 'draft', 'pending', 'private'),
            'meta_key'       => 'official_id',
            'meta_value'     => $grant_id,
            'posts_per_page' => 1,
            'fields'         => 'ids',
        );

        $posts = get_posts($args);

        return !empty($posts) ? $posts[0] : null;
    }

    /**
     * ログ記録
     *
     * @param string $level ログレベル
     * @param string $message メッセージ
     * @param array $context コンテキストデータ
     */
    private function log($level, $message, $context = array()) {
        if (!function_exists('auto_grants_log')) {
            return;
        }

        auto_grants_log($level, $message, $context);
    }
}