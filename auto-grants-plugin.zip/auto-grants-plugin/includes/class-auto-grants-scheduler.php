<?php
/**
 * スケジュール管理クラス
 * 
 * @package Auto_Grants
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Auto_Grants_Scheduler クラス
 */
class Auto_Grants_Scheduler {

    /**
     * 日次同期イベント名
     */
    const DAILY_SYNC_EVENT = 'auto_grants_daily_sync';

    /**
     * AI処理イベント名
     */
    const AI_PROCESS_EVENT = 'auto_grants_ai_process';

    /**
     * ロック用オプション名
     */
    const LOCK_OPTION = 'auto_grants_process_lock';

    /**
     * ロックタイムアウト（秒）
     */
    const LOCK_TIMEOUT = 3600; // 1時間

    /**
     * コンストラクタ
     */
    public function __construct() {
        $this->init_hooks();
    }

    /**
     * フックの初期化
     */
    private function init_hooks() {
        // 日次同期
        add_action(self::DAILY_SYNC_EVENT, array($this, 'daily_sync'));
        add_filter('cron_schedules', array($this, 'add_cron_schedules'));
        
        // AI処理
        add_action(self::AI_PROCESS_EVENT, array($this, 'ai_process'));
        
        // カスタムスケジュール
        add_action('wp', array($this, 'schedule_events'));
        
        // 管理画面での手動実行
        add_action('wp_ajax_auto_grants_manual_sync', array($this, 'ajax_manual_sync'));
        add_action('wp_ajax_auto_grants_manual_ai', array($this, 'ajax_manual_ai'));
    }

    /**
     * カスタムcronスケジュールを追加
     *
     * @param array $schedules 既存のスケジュール
     * @return array カスタムスケジュールを追加した配列
     */
    public function add_cron_schedules($schedules) {
        // 30分ごと
        $schedules['every_30_minutes'] = array(
            'interval' => 30 * MINUTE_IN_SECONDS,
            'display'  => __('30分ごと', 'auto-grants'),
        );

        // 2時間ごと
        $schedules['every_2_hours'] = array(
            'interval' => 2 * HOUR_IN_SECONDS,
            'display'  => __('2時間ごと', 'auto-grants'),
        );

        // 3時間ごと
        $schedules['every_3_hours'] = array(
            'interval' => 3 * HOUR_IN_SECONDS,
            'display'  => __('3時間ごと', 'auto-grants'),
        );

        // 6時間ごと
        $schedules['every_6_hours'] = array(
            'interval' => 6 * HOUR_IN_SECONDS,
            'display'  => __('6時間ごと', 'auto-grants'),
        );

        // 12時間ごと
        $schedules['every_12_hours'] = array(
            'interval' => 12 * HOUR_IN_SECONDS,
            'display'  => __('12時間ごと', 'auto-grants'),
        );

        return $schedules;
    }

    /**
     * イベントをスケジュール
     */
    public function schedule_events() {
        // 日次同期のスケジュール
        if (!wp_next_scheduled(self::DAILY_SYNC_EVENT)) {
            $sync_time = get_option('auto_grants_sync_time', '03:00');
            $time_parts = explode(':', $sync_time);
            $hour = isset($time_parts[0]) ? intval($time_parts[0]) : 3;
            $minute = isset($time_parts[1]) ? intval($time_parts[1]) : 0;
            
            $timestamp = mktime($hour, $minute, 0);
            if ($timestamp < time()) {
                $timestamp = strtotime('+1 day', $timestamp);
            }
            
            wp_schedule_event($timestamp, 'daily', self::DAILY_SYNC_EVENT);
            $this->log('info', '日次同期イベントをスケジュール', array('time' => date('Y-m-d H:i:s', $timestamp)));
        }

        // AI処理のスケジュール
        if (!wp_next_scheduled(self::AI_PROCESS_EVENT)) {
            $frequency = get_option('auto_grants_ai_frequency', 'hourly');
            wp_schedule_event(time(), $frequency, self::AI_PROCESS_EVENT);
            $this->log('info', 'AI処理イベントをスケジュール', array('frequency' => $frequency));
        }
    }

    /**
     * 日次同期処理
     */
    public function daily_sync() {
        $this->log('info', '日次同期処理開始');

        // ロックチェック
        if ($this->is_locked('daily_sync')) {
            $this->log('warning', '日次同期処理が既に実行中のためスキップ');
            return;
        }

        // ロック取得
        $this->acquire_lock('daily_sync');

        try {
            $api = auto_grants()->get_api_manager();
            
            // 最終同期日時を取得
            $last_sync = get_option('auto_grants_last_sync_date', date('Y-m-d H:i:s', strtotime('-1 day')));
            
            // 新規補助金を取得
            $grants = $api->fetch_new_grants($last_sync);
            
            if (is_wp_error($grants)) {
                $this->log('error', '補助金取得エラー', array('error' => $grants->get_error_message()));
                return;
            }

            if (empty($grants)) {
                $this->log('info', '新規補助金なし', array('last_sync' => $last_sync));
            } else {
                $this->log('info', '新規補助金発見', array('count' => count($grants)));
                
                $imported = 0;
                $errors = 0;

                foreach ($grants as $grant) {
                    // 既存チェック
                    if (isset($grant['id'])) {
                        $exists = $api->grant_exists($grant['id']);
                        if ($exists) {
                            $this->log('info', '既存補助金のためスキップ', array('grant_id' => $grant['id']));
                            continue;
                        }

                        // 詳細情報を取得
                        $detail = $api->fetch_grant_detail($grant['id']);
                        if (is_wp_error($detail)) {
                            $errors++;
                            $this->log('error', '補助金詳細取得エラー', array('grant_id' => $grant['id'], 'error' => $detail->get_error_message()));
                            continue;
                        }

                        // WordPress投稿データに変換
                        $post_data = $api->convert_to_post_data($detail);
                        
                        // 投稿作成
                        $post_id = wp_insert_post($post_data, true);
                        
                        if (is_wp_error($post_id)) {
                            $errors++;
                            $this->log('error', '投稿作成エラー', array('grant_id' => $grant['id'], 'error' => $post_id->get_error_message()));
                        } else {
                            $imported++;
                            $this->log('info', '投稿作成完了', array('post_id' => $post_id, 'grant_id' => $grant['id']));
                        }
                    }
                }

                $this->log('info', '日次同期完了', array('imported' => $imported, 'errors' => $errors));
            }

            // 最終同期日時を更新
            update_option('auto_grants_last_sync_date', current_time('mysql'));
            
            // 統計情報を更新
            $this->update_sync_stats($imported, $errors);

        } catch (Exception $e) {
            $this->log('error', '日次同期エラー', array('error' => $e->getMessage()));
        } finally {
            // ロック解除
            $this->release_lock('daily_sync');
        }

        $this->log('info', '日次同期処理完了');
    }

    /**
     * AI処理
     */
    public function ai_process() {
        $this->log('info', 'AI処理開始');

        // ロックチェック
        if ($this->is_locked('ai_process')) {
            $this->log('warning', 'AI処理が既に実行中のためスキップ');
            return;
        }

        // ロック取得
        $this->acquire_lock('ai_process');

        try {
            $ai_manager = auto_grants()->get_ai_manager();
            
            if (!$ai_manager->is_enabled()) {
                $this->log('warning', 'Gemini APIが有効ではないためスキップ');
                return;
            }

            // バッチサイズを取得
            $batch_size = get_option('auto_grants_batch_size', 5);
            
            // AI一括処理実行
            $result = $ai_manager->process_posts_batch($batch_size);
            
            if (is_wp_error($result)) {
                $this->log('error', 'AI処理エラー', array('error' => $result->get_error_message()));
                return;
            }

            $this->log('info', 'AI処理完了', $result);
            
            // 統計情報を更新
            if (isset($result['processed'])) {
                $this->update_ai_stats($result['processed'], $result['errors']);
            }

        } catch (Exception $e) {
            $this->log('error', 'AI処理エラー', array('error' => $e->getMessage()));
        } finally {
            // ロック解除
            $this->release_lock('ai_process');
        }

        $this->log('info', 'AI処理完了');
    }

    /**
     * 手動同期（AJAX）
     */
    public function ajax_manual_sync() {
        // 権限チェック
        if (!current_user_can('manage_options')) {
            wp_die('権限がありません。');
        }

        // ノンスチェック
        check_ajax_referer('auto_grants_manual_sync', 'nonce');

        $this->log('info', '手動同期開始');

        // 同期実行
        $this->daily_sync();

        // 結果を返却
        $last_sync = get_option('auto_grants_last_sync_date');
        $stats = get_option('auto_grants_sync_stats', array());

        wp_send_json_success(array(
            'message' => '同期完了',
            'last_sync' => $last_sync,
            'stats' => $stats,
        ));
    }

    /**
     * 手動AI処理（AJAX）
     */
    public function ajax_manual_ai() {
        // 権限チェック
        if (!current_user_can('manage_options')) {
            wp_die('権限がありません。');
        }

        // ノンスチェック
        check_ajax_referer('auto_grants_manual_ai', 'nonce');

        $batch_size = isset($_POST['batch_size']) ? intval($_POST['batch_size']) : 5;
        
        $this->log('info', '手動AI処理開始', array('batch_size' => $batch_size));

        $ai_manager = auto_grants()->get_ai_manager();
        $result = $ai_manager->process_posts_batch($batch_size);

        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }

        wp_send_json_success($result);
    }

    /**
     * ロック取得
     *
     * @param string $process プロセス名
     * @return bool 成功/失敗
     */
    private function acquire_lock($process) {
        $lock_key = self::LOCK_OPTION . '_' . $process;
        $lock_data = get_option($lock_key);
        
        if ($lock_data !== false) {
            $lock_time = isset($lock_data['time']) ? intval($lock_data['time']) : 0;
            if (time() - $lock_time < self::LOCK_TIMEOUT) {
                return false; // 既にロックされている
            }
        }

        // ロックを設定
        update_option($lock_key, array(
            'process' => $process,
            'time'    => time(),
            'pid'     => getmypid(),
        ));

        return true;
    }

    /**
     * ロック解除
     *
     * @param string $process プロセス名
     */
    private function release_lock($process) {
        $lock_key = self::LOCK_OPTION . '_' . $process;
        delete_option($lock_key);
    }

    /**
     * ロックチェック
     *
     * @param string $process プロセス名
     * @return bool ロック中かどうか
     */
    private function is_locked($process) {
        $lock_key = self::LOCK_OPTION . '_' . $process;
        $lock_data = get_option($lock_key);
        
        if ($lock_data === false) {
            return false;
        }

        $lock_time = isset($lock_data['time']) ? intval($lock_data['time']) : 0;
        if (time() - $lock_time > self::LOCK_TIMEOUT) {
            // タイムアウトしているロックは解除
            $this->release_lock($process);
            return false;
        }

        return true;
    }

    /**
     * 同期統計情報を更新
     *
     * @param int $imported インポート件数
     * @param int $errors エラー件数
     */
    private function update_sync_stats($imported, $errors) {
        $stats = get_option('auto_grants_sync_stats', array(
            'total_imported' => 0,
            'total_errors'   => 0,
            'last_imported'  => 0,
            'last_errors'    => 0,
            'last_run'       => '',
        ));

        $stats['total_imported'] += $imported;
        $stats['total_errors']   += $errors;
        $stats['last_imported']   = $imported;
        $stats['last_errors']     = $errors;
        $stats['last_run']        = current_time('mysql');

        update_option('auto_grants_sync_stats', $stats);
    }

    /**
     * AI統計情報を更新
     *
     * @param int $processed 処理件数
     * @param int $errors エラー件数
     */
    private function update_ai_stats($processed, $errors) {
        $stats = get_option('auto_grants_ai_stats', array(
            'total_processed' => 0,
            'total_errors'    => 0,
            'last_processed'  => 0,
            'last_errors'     => 0,
            'last_run'        => '',
        ));

        $stats['total_processed'] += $processed;
        $stats['total_errors']  += $errors;
        $stats['last_processed']  = $processed;
        $stats['last_errors']     = $errors;
        $stats['last_run']        = current_time('mysql');

        update_option('auto_grants_ai_stats', $stats);
    }

    /**
     * 次回実行時刻を取得
     *
     * @param string $event イベント名
     * @return string 次回実行時刻
     */
    public function get_next_scheduled_time($event) {
        $timestamp = wp_next_scheduled($event);
        if ($timestamp) {
            return date('Y-m-d H:i:s', $timestamp);
        }
        return 'スケジュールされていません';
    }

    /**
     * 最終実行時刻を取得
     *
     * @param string $type タイプ（sync, ai）
     * @return string 最終実行時刻
     */
    public function get_last_run_time($type) {
        $option_name = 'auto_grants_last_' . $type . '_date';
        $last_run = get_option($option_name);
        return $last_run ? $last_run : '実行履歴なし';
    }

    /**
     * 統計情報を取得
     *
     * @param string $type タイプ（sync, ai）
     * @return array 統計情報
     */
    public function get_stats($type) {
        $option_name = 'auto_grants_' . $type . '_stats';
        return get_option($option_name, array());
    }

    /**
     * ログ記録
     *
     * @param string $level ログレベル
     * @param string $message メッセージ
     * @param array $context コンテキストデータ
     */
    private function log($level, $message, $context = array()) {
        if (!function_exists('auto_grants_log')) {
            return;
        }

        auto_grants_log($level, $message, $context);
    }
}