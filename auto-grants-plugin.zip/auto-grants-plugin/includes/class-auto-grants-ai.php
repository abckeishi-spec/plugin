<?php
/**
 * AI記事生成クラス
 * 
 * @package Auto_Grants
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Auto_Grants_AI クラス
 */
class Auto_Grants_AI {

    /**
     * Gemini APIキー
     */
    private $api_key;

    /**
     * Gemini APIベースURL
     */
    private $api_base_url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest';

    /**
     * リトライ回数
     */
    private $max_retries = 3;

    /**
     * タイムアウト（秒）
     */
    private $timeout = 60;

    /**
     * コンテンツ生成パラメータ
     */
    private $generation_config = array(
        'temperature' => 0.7,
        'topK' => 40,
        'topP' => 0.95,
        'maxOutputTokens' => 8192,
    );

    /**
     * コンストラクタ
     */
    public function __construct() {
        $this->api_key = get_option('auto_grants_gemini_api_key');
    }

    /**
     * AIが有効かチェック
     *
     * @return bool
     */
    public function is_enabled() {
        return !empty($this->api_key);
    }

    /**
     * 投稿にAI処理を適用
     *
     * @param int $post_id 投稿ID
     * @return bool|WP_Error 成功/エラー
     */
    public function process_post($post_id) {
        if (!$this->is_enabled()) {
            return new WP_Error('ai_disabled', 'Gemini APIキーが設定されていません。');
        }

        $post = get_post($post_id);
        if (!$post || $post->post_type !== AUTO_GRANTS_POST_TYPE) {
            return new WP_Error('invalid_post', '無効な投稿です。');
        }

        // 既にAI処理済みかチェック
        $ai_processed = get_post_meta($post_id, 'ai_processed', true);
        if ($ai_processed === '1') {
            $this->log('info', 'AI処理済みのためスキップ', array('post_id' => $post_id));
            return true;
        }

        $this->log('info', 'AI処理開始', array('post_id' => $post_id, 'title' => $post->post_title));

        // 補助金データを取得
        $grant_data = $this->get_grant_data($post_id);
        if (empty($grant_data)) {
            return new WP_Error('no_grant_data', '補助金データが見つかりません。');
        }

        try {
            // AIコンテンツ生成
            $ai_content = $this->generate_content($grant_data);
            if (is_wp_error($ai_content)) {
                return $ai_content;
            }

            // 投稿を更新
            $result = $this->update_post_with_ai_content($post_id, $ai_content);
            if (is_wp_error($result)) {
                return $result;
            }

            // AI処理済みフラグを設定
            update_post_meta($post_id, 'ai_processed', '1');
            update_post_meta($post_id, 'ai_processed_date', current_time('mysql'));

            $this->log('info', 'AI処理完了', array('post_id' => $post_id));

            return true;

        } catch (Exception $e) {
            $this->log('error', 'AI処理エラー', array('post_id' => $post_id, 'error' => $e->getMessage()));
            return new WP_Error('ai_processing_error', 'AI処理中にエラーが発生しました: ' . $e->getMessage());
        }
    }

    /**
     * 複数の投稿を一括処理
     *
     * @param int $limit 処理上限
     * @return array 処理結果
     */
    public function process_posts_batch($limit = 5) {
        if (!$this->is_enabled()) {
            return new WP_Error('ai_disabled', 'Gemini APIが有効ではありません。');
        }

        $this->log('info', 'AI一括処理開始', array('limit' => $limit));

        // AI未処理の下書き投稿を取得
        $args = array(
            'post_type'      => AUTO_GRANTS_POST_TYPE,
            'post_status'    => 'draft',
            'posts_per_page' => $limit,
            'meta_query'     => array(
                'relation' => 'OR',
                array(
                    'key'     => 'ai_processed',
                    'compare' => 'NOT EXISTS',
                ),
                array(
                    'key'     => 'ai_processed',
                    'value'   => '1',
                    'compare' => '!=',
                ),
            ),
            'orderby' => 'date',
            'order'   => 'ASC',
        );

        $posts = get_posts($args);

        if (empty($posts)) {
            $this->log('info', '処理対象の投稿が見つかりません');
            return array('processed' => 0, 'errors' => 0, 'message' => '処理対象の投稿が見つかりませんでした。');
        }

        $processed = 0;
        $errors = 0;
        $results = array();

        foreach ($posts as $post) {
            $result = $this->process_post($post->ID);
            
            if (is_wp_error($result)) {
                $errors++;
                $results[] = array(
                    'post_id' => $post->ID,
                    'status'  => 'error',
                    'message' => $result->get_error_message(),
                );
            } else {
                $processed++;
                $results[] = array(
                    'post_id' => $post->ID,
                    'status'  => 'success',
                    'message' => 'AI処理完了',
                );
            }

            // レート制限対策：少し待機
            usleep(500000); // 0.5秒
        }

        $this->log('info', 'AI一括処理完了', array('processed' => $processed, 'errors' => $errors));

        return array(
            'processed' => $processed,
            'errors'    => $errors,
            'results'   => $results,
            'message'   => sprintf('%d件処理完了（%d件エラー）', $processed, $errors),
        );
    }

    /**
     * AIコンテンツ生成
     *
     * @param array $grant_data 補助金データ
     * @return array|WP_Error 生成されたコンテンツ
     */
    private function generate_content($grant_data) {
        $prompt = $this->build_prompt($grant_data);
        
        $this->log('info', 'AIコンテンツ生成開始', array('grant_id' => $grant_data['official_id']));

        $response = $this->call_gemini_api($prompt);

        if (is_wp_error($response)) {
            return $response;
        }

        // レスポンスをパース
        $content = $this->parse_ai_response($response);
        if (is_wp_error($content)) {
            return $content;
        }

        $this->log('info', 'AIコンテンツ生成完了', array('grant_id' => $grant_data['official_id']));

        return $content;
    }

    /**
     * プロンプト構築
     *
     * @param array $grant_data 補助金データ
     * @return string プロンプト
     */
    private function build_prompt($grant_data) {
        $base_prompt = get_option('auto_grants_ai_prompt', $this->get_default_prompt());
        
        // 補助金情報を整形
        $grant_info = $this->format_grant_info($grant_data);
        
        $full_prompt = $base_prompt . "\n\n" . $grant_info . "\n\n【指示】\n上記の補助金情報を基に、申請者にとって有益な記事を作成してください。必ずJSON形式で以下の構造で返答してください:\n\n{\n  \"title\": \"(SEOを意識した記事タイトル)\",\n  \"content\": \"(整形された記事本文)\",\n  \"summary\": \"(3行程度の要約、箇条書き)\",\n  \"category\": \"(補助金カテゴリー)\",\n  \"difficulty\": \"(申請難易度: easy, medium, hard)\",\n  \"keywords\": [\"(関連キーワード1)\", \"(関連キーワード2)\"]\n}";

        return $full_prompt;
    }

    /**
     * 補助金情報をフォーマット
     *
     * @param array $grant_data 補助金データ
     * @return string フォーマットされた情報
     */
    private function format_grant_info($grant_data) {
        $info = "【補助金基本情報】\n";
        $info .= "名称: " . ($grant_data['post_title'] ?? '不明') . "\n";
        $info .= "対象地域: " . ($grant_data['target_area_search'] ?? '全国') . "\n";
        $info .= "対象業種: " . ($grant_data['industry'] ?? '不特定') . "\n";
        $info .= "利用目的: " . ($grant_data['use_purpose'] ?? '不特定') . "\n";
        $info .= "対象者規模: " . ($grant_data['target_number_of_employees'] ?? '不特定') . "\n";
        
        if (isset($grant_data['max_amount_numeric']) && $grant_data['max_amount_numeric'] > 0) {
            $info .= "最大支援額: " . number_format($grant_data['max_amount_numeric']) . "円\n";
        }
        
        if (isset($grant_data['subsidy_rate'])) {
            $info .= "支援率: " . $grant_data['subsidy_rate'] . "\n";
        }
        
        if (isset($grant_data['acceptance_start_datetime'])) {
            $info .= "募集開始: " . $grant_data['acceptance_start_datetime'] . "\n";
        }
        
        if (isset($grant_data['acceptance_end_datetime'])) {
            $info .= "募集終了: " . $grant_data['acceptance_end_datetime'] . "\n";
        }
        
        if (isset($grant_data['organization'])) {
            $info .= "実施組織: " . $grant_data['organization'] . "\n";
        }
        
        if (isset($grant_data['official_url'])) {
            $info .= "公式URL: " . $grant_data['official_url'] . "\n";
        }
        
        return $info;
    }

    /**
     * Gemini API呼び出し
     *
     * @param string $prompt プロンプト
     * @return array|WP_Error APIレスポンス
     */
    private function call_gemini_api($prompt) {
        $url = $this->api_base_url . ':generateContent?key=' . urlencode($this->api_key);
        
        $data = array(
            'contents' => array(
                array(
                    'parts' => array(
                        array('text' => $prompt)
                    )
                )
            ),
            'generationConfig' => $this->generation_config,
        );

        $args = array(
            'method'  => 'POST',
            'timeout' => $this->timeout,
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => wp_json_encode($data),
        );

        $retries = 0;
        while ($retries < $this->max_retries) {
            $response = wp_remote_post($url, $args);

            if (is_wp_error($response)) {
                $retries++;
                $this->log('warning', 'Gemini API呼び出し失敗（リトライ）', array('retry' => $retries, 'error' => $response->get_error_message()));
                sleep(2);
                continue;
            }

            $response_code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if ($response_code === 200) {
                return $data;
            } elseif ($response_code === 429) {
                // レート制限
                $retry_after = 60;
                $this->log('warning', 'Gemini APIレート制限', array('retry_after' => $retry_after));
                sleep($retry_after);
                $retries++;
                continue;
            } else {
                $error_message = isset($data['error']['message']) ? $data['error']['message'] : 'Gemini APIエラーが発生しました。';
                return new WP_Error('gemini_api_error', $error_message, array('status' => $response_code));
            }
        }

        return new WP_Error('max_retries_exceeded', 'Gemini APIの最大リトライ回数に達しました。');
    }

    /**
     * AIレスポンスをパース
     *
     * @param array $response APIレスポンス
     * @return array|WP_Error パースされたコンテンツ
     */
    private function parse_ai_response($response) {
        if (!isset($response['candidates'][0]['content']['parts'][0]['text'])) {
            return new WP_Error('invalid_response', 'AIからの応答が不正です。');
        }

        $ai_text = $response['candidates'][0]['content']['parts'][0]['text'];
        
        // JSONを抽出
        preg_match('/\{[\s\S]*\}/', $ai_text, $matches);
        if (empty($matches)) {
            return new WP_Error('json_not_found', 'AI応答からJSONを抽出できませんでした。');
        }

        $json_str = $matches[0];
        $content = json_decode($json_str, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            return new WP_Error('json_decode_error', 'JSONデコードエラー: ' . json_last_error_msg());
        }

        // 必須フィールドの検証
        $required_fields = array('title', 'content', 'summary', 'category', 'difficulty');
        foreach ($required_fields as $field) {
            if (!isset($content[$field])) {
                return new WP_Error('missing_field', '必須フィールドが不足しています: ' . $field);
            }
        }

        return $content;
    }

    /**
     * 投稿をAIコンテンツで更新
     *
     * @param int $post_id 投稿ID
     * @param array $ai_content AI生成コンテンツ
     * @return bool|WP_Error 成功/エラー
     */
    private function update_post_with_ai_content($post_id, $ai_content) {
        $post_data = array(
            'ID'           => $post_id,
            'post_title'   => sanitize_text_field($ai_content['title']),
            'post_content' => wp_kses_post($ai_content['content']),
            'post_status'  => 'publish', // 公開ステータスに変更
        );

        $result = wp_update_post($post_data, true);

        if (is_wp_error($result)) {
            return $result;
        }

        // カスタムフィールドを更新
        update_post_meta($post_id, 'ai_summary', wp_kses_post($ai_content['summary']));
        
        if (isset($ai_content['keywords']) && is_array($ai_content['keywords'])) {
            update_post_meta($post_id, 'ai_keywords', $ai_content['keywords']);
        }

        // カテゴリーを設定
        if (!empty($ai_content['category'])) {
            $this->set_grant_category($post_id, $ai_content['category']);
        }

        // 難易度を設定
        if (!empty($ai_content['difficulty']) && in_array($ai_content['difficulty'], array('easy', 'medium', 'hard'))) {
            $this->set_grant_difficulty($post_id, $ai_content['difficulty']);
        }

        return true;
    }

    /**
     * 補助金カテゴリーを設定
     *
     * @param int $post_id 投稿ID
     * @param string $category カテゴリー名
     */
    private function set_grant_category($post_id, $category) {
        $term = term_exists($category, 'grant_category');
        if (!$term) {
            $term = wp_insert_term($category, 'grant_category');
        }

        if (!is_wp_error($term)) {
            $term_id = is_array($term) ? $term['term_id'] : $term;
            wp_set_post_terms($post_id, array($term_id), 'grant_category');
        }
    }

    /**
     * 申請難易度を設定
     *
     * @param int $post_id 投稿ID
     * @param string $difficulty 難易度
     */
    private function set_grant_difficulty($post_id, $difficulty) {
        wp_set_post_terms($post_id, array($difficulty), 'grant_difficulty');
    }

    /**
     * 補助金データを取得
     *
     * @param int $post_id 投稿ID
     * @return array 補助金データ
     */
    private function get_grant_data($post_id) {
        $post = get_post($post_id);
        if (!$post) {
            return array();
        }

        $grant_data = array(
            'post_title' => $post->post_title,
            'post_content' => $post->post_content,
        );

        // メタデータを取得
        $meta_fields = array(
            'official_id', 'name', 'catch_phrase', 'use_purpose', 'industry',
            'target_area_search', 'target_area_detail', 'target_number_of_employees',
            'subsidy_rate', 'max_amount_numeric', 'acceptance_start_datetime',
            'acceptance_end_datetime', 'official_url', 'organization'
        );

        foreach ($meta_fields as $field) {
            $grant_data[$field] = get_post_meta($post_id, $field, true);
        }

        return $grant_data;
    }

    /**
     * デフォルトプロンプト取得
     *
     * @return string デフォルトプロンプト
     */
    private function get_default_prompt() {
        return 'あなたは補助金申請の専門家です。以下の補助金情報を基に、申請者にとって有益な記事を作成してください。

【記事作成ガイドライン】
1. タイトルはSEOを意識し、補助金名＋「申請方法」や「利用方法」などのキーワードを含める
2. 本文は以下の構成で書く：
   - この補助金とは（3行程度）
   - 対象者・条件
   - 支援内容（金額、期間など）
   - 申請方法と必要書類
   - 申請のポイントと注意事項
   - よくある質問
3. 専門用語は避け、初心者にも分かりやすい言葉で説明する
4. 申請締切が近い場合は、その旨を強調する
5. 3行要約は、箇条書きで記事の要点を整理する

【補助金情報】';
    }

    /**
     * ログ記録
     *
     * @param string $level ログレベル
     * @param string $message メッセージ
     * @param array $context コンテキストデータ
     */
    private function log($level, $message, $context = array()) {
        if (!function_exists('auto_grants_log')) {
            return;
        }

        auto_grants_log($level, $message, $context);
    }
}