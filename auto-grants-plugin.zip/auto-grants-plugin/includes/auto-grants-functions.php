<?php
/**
 * ヘルパー関数
 * 
 * @package Auto_Grants
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * ログを記録
 *
 * @param string $level ログレベル (error, warning, info, debug)
 * @param string $message ログメッセージ
 * @param array  $context 追加コンテキストデータ
 * @return bool 成功/失敗
 */
function auto_grants_log($level, $message, $context = array()) {
    // ログレベルをチェック
    $log_level = get_option('auto_grants_log_level', 'info');
    if ($log_level === 'none') {
        return false;
    }

    $levels = array('debug' => 0, 'info' => 1, 'warning' => 2, 'error' => 3);
    if (isset($levels[$log_level]) && isset($levels[$level])) {
        if ($levels[$level] < $levels[$log_level]) {
            return false;
        }
    }

    // ログファイルパス
    $log_file = AUTO_GRANTS_LOG_DIR . 'auto-grants.log';

    // ログディレクトリが存在しない場合は作成
    if (!file_exists(AUTO_GRANTS_LOG_DIR)) {
        wp_mkdir_p(AUTO_GRANTS_LOG_DIR);
    }

    // ログデータを構築
    $log_data = array(
        'datetime' => current_time('mysql'),
        'level'    => $level,
        'message'  => $message,
        'context'  => $context,
        'uri'      = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
        'ip'       => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '',
    );

    // JSON形式でログを書き込む
    $log_line = json_encode($log_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";

    // ファイルに書き込み
    $result = file_put_contents($log_file, $log_line, FILE_APPEND | LOCK_EX);

    // エラー時はWordPressのログにも記録
    if ($result === false) {
        error_log('Auto Grants ログ書き込みエラー: ' . $message);
    }

    return $result !== false;
}

/**
 * エラーログを記録
 *
 * @param string $message エラーメッセージ
 * @param array  $context 追加コンテキストデータ
 * @return bool 成功/失敗
 */
function auto_grants_error_log($message, $context = array()) {
    return auto_grants_log('error', $message, $context);
}

/**
 * 警告ログを記録
 *
 * @param string $message 警告メッセージ
 * @param array  $context 追加コンテキストデータ
 * @return bool 成功/失敗
 */
function auto_grants_warning_log($message, $context = array()) {
    return auto_grants_log('warning', $message, $context);
}

/**
 * 情報ログを記録
 *
 * @param string $message 情報メッセージ
 * @param array  $context 追加コンテキストデータ
 * @return bool 成功/失敗
 */
function auto_grants_info_log($message, $context = array()) {
    return auto_grants_log('info', $message, $context);
}

/**
 * デバッグログを記録
 *
 * @param string $message デバッグメッセージ
 * @param array  $context 追加コンテキストデータ
 * @return bool 成功/失敗
 */
function auto_grants_debug_log($message, $context = array()) {
    return auto_grants_log('debug', $message, $context);
}

/**
 * ログファイルをクリア
 *
 * @return bool 成功/失敗
 */
function auto_grants_clear_logs() {
    $log_file = AUTO_GRANTS_LOG_DIR . 'auto-grants.log';
    
    if (file_exists($log_file)) {
        return file_put_contents($log_file, '') !== false;
    }

    return true;
}

/**
 * ログファイルを取得
 *
 * @param int $limit 取得行数
 * @return array ログエントリ
 */
function auto_grants_get_logs($limit = 1000) {
    $log_file = AUTO_GRANTS_LOG_DIR . 'auto-grants.log';
    
    if (!file_exists($log_file)) {
        return array();
    }

    $logs = array();
    $lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    
    if ($lines === false) {
        return array();
    }

    // 最新のログから指定件数取得
    $lines = array_slice($lines, -$limit);
    
    foreach ($lines as $line) {
        $log = json_decode($line, true);
        if ($log && isset($log['datetime'], $log['level'], $log['message'])) {
            $logs[] = $log;
        }
    }

    return array_reverse($logs); // 新しい順にする
}

/**
 * 特定のレベルのログを取得
 *
 * @param string $level ログレベル
 * @param int    $limit 取得行数
 * @return array フィルタリングされたログ
 */
function auto_grants_get_logs_by_level($level, $limit = 1000) {
    $logs = auto_grants_get_logs($limit);
    $filtered_logs = array();

    foreach ($logs as $log) {
        if (isset($log['level']) && $log['level'] === $level) {
            $filtered_logs[] = $log;
        }
    }

    return $filtered_logs;
}

/**
 * 日付でログをフィルタリング
 *
 * @param string $start_date 開始日（Y-m-d）
 * @param string $end_date   終了日（Y-m-d）
 * @param int    $limit      取得行数
 * @return array フィルタリングされたログ
 */
function auto_grants_get_logs_by_date($start_date, $end_date = null, $limit = 1000) {
    if ($end_date === null) {
        $end_date = date('Y-m-d');
    }

    $logs = auto_grants_get_logs($limit);
    $filtered_logs = array();

    foreach ($logs as $log) {
        if (isset($log['datetime'])) {
            $log_date = substr($log['datetime'], 0, 10);
            if ($log_date >= $start_date && $log_date <= $end_date) {
                $filtered_logs[] = $log;
            }
        }
    }

    return $filtered_logs;
}

/**
 * 補助金が存在するかチェック
 *
 * @param string $grant_id 補助金ID
 * @return int|null 既存投稿IDまたはnull
 */
function auto_grants_grant_exists($grant_id) {
    if (empty($grant_id)) {
        return null;
    }

    $args = array(
        'post_type'      => AUTO_GRANTS_POST_TYPE,
        'post_status'    => array('publish', 'draft', 'pending', 'private'),
        'meta_key'       => 'official_id',
        'meta_value'     => $grant_id,
        'posts_per_page' => 1,
        'fields'         => 'ids',
    );

    $posts = get_posts($args);

    return !empty($posts) ? $posts[0] : null;
}

/**
 * 補助金データを取得
 *
 * @param int $post_id 投稿ID
 * @return array 補助金データ
 */
function auto_grants_get_grant_data($post_id) {
    $post = get_post($post_id);
    if (!$post || $post->post_type !== AUTO_GRANTS_POST_TYPE) {
        return array();
    }

    $grant_data = array(
        'post_title'   => $post->post_title,
        'post_content' => $post->post_content,
        'post_status'  => $post->post_status,
        'post_date'    => $post->post_date,
    );

    // メタデータを取得
    $meta_fields = array(
        'official_id', 'name', 'catch_phrase', 'use_purpose', 'industry',
        'target_area_search', 'target_area_detail', 'target_number_of_employees',
        'subsidy_rate', 'max_amount_numeric', 'max_amount', 'acceptance_start_datetime',
        'acceptance_end_datetime', 'deadline_date', 'deadline_text', 'application_status',
        'organization', 'difficulty_level', 'official_url', 'ai_summary', 'ai_processed',
        'ai_processed_date', 'ai_keywords', 'raw_data'
    );

    foreach ($meta_fields as $field) {
        $value = get_post_meta($post_id, $field, true);
        if ($value !== '') {
            $grant_data[$field] = $value;
        }
    }

    // ACFフィールドからも取得（ACFが有効な場合）
    if (function_exists('get_field')) {
        $acf_fields = array(
            'ai_summary', 'max_amount', 'max_amount_numeric', 'deadline_date',
            'deadline_text', 'application_status', 'organization', 'difficulty_level',
            'official_url', 'official_id', 'ai_processed', 'ai_processed_date',
            'subsidy_rate', 'target_area_detail', 'acceptance_start_datetime',
            'acceptance_end_datetime', 'raw_data'
        );

        foreach ($acf_fields as $field) {
            $value = get_field($field, $post_id);
            if ($value !== false && $value !== null && $value !== '') {
                $grant_data[$field] = $value;
            }
        }
    }

    return $grant_data;
}

/**
 * 補助金ステータスを取得
 *
 * @param int $post_id 投稿ID
 * @return string ステータス
 */
function auto_grants_get_status($post_id) {
    $status = get_post_meta($post_id, 'application_status', true);
    $status_labels = array(
        'open'     => '募集中',
        'closed'   => '募集終了',
        'upcoming' => '募集開始前',
    );

    return isset($status_labels[$status]) ? $status_labels[$status] : '不明';
}

/**
 * 申請難易度を取得
 *
 * @param int $post_id 投稿ID
 * @return string 難易度
 */
function auto_grants_get_difficulty($post_id) {
    $difficulty = get_post_meta($post_id, 'difficulty_level', true);
    $difficulty_labels = array(
        'easy'   => '易しい',
        'medium' => '普通',
        'hard'   => '難しい',
    );

    return isset($difficulty_labels[$difficulty]) ? $difficulty_labels[$difficulty] : '未設定';
}

/**
 * 締切日を取得
 *
 * @param int $post_id 投稿ID
 * @return string 締切日
 */
function auto_grants_get_deadline($post_id) {
    $deadline = get_post_meta($post_id, 'deadline_text', true);
    return $deadline ?: '情報なし';
}

/**
 * 最大支援額を取得
 *
 * @param int $post_id 投稿ID
 * @return string 最大支援額
 */
function auto_grants_get_max_amount($post_id) {
    $amount = get_post_meta($post_id, 'max_amount', true);
    return $amount ?: '情報なし';
}

/**
 * AI処理済みかチェック
 *
 * @param int $post_id 投稿ID
 * @return bool AI処理済みかどうか
 */
function auto_grants_is_ai_processed($post_id) {
    return get_post_meta($post_id, 'ai_processed', true) === '1';
}

/**
 * AI処理日時を取得
 *
 * @param int $post_id 投稿ID
 * @return string AI処理日時
 */
function auto_grants_get_ai_processed_date($post_id) {
    $date = get_post_meta($post_id, 'ai_processed_date', true);
    return $date ?: '未処理';
}

/**
 * 未処理の下書き投稿数を取得
 *
 * @return int 未処理の下書き投稿数
 */
function auto_grants_get_unprocessed_draft_count() {
    $args = array(
        'post_type'      => AUTO_GRANTS_POST_TYPE,
        'post_status'    => 'draft',
        'posts_per_page' => -1,
        'meta_query'     => array(
            'relation' => 'OR',
            array(
                'key'     => 'ai_processed',
                'compare' => 'NOT EXISTS',
            ),
            array(
                'key'     => 'ai_processed',
                'value'   => '1',
                'compare' => '!=',
            ),
        ),
        'fields' => 'ids',
    );

    $posts = get_posts($args);
    return count($posts);
}

/**
 * 次回同期時刻を取得
 *
 * @return string 次回同期時刻
 */
function auto_grants_get_next_sync_time() {
    $scheduler = auto_grants()->scheduler;
    if ($scheduler) {
        return $scheduler->get_next_scheduled_time('auto_grants_daily_sync');
    }
    return 'スケジュールされていません';
}

/**
 * 次回AI処理時刻を取得
 *
 * @return string 次回AI処理時刻
 */
function auto_grants_get_next_ai_time() {
    $scheduler = auto_grants()->scheduler;
    if ($scheduler) {
        return $scheduler->get_next_scheduled_time('auto_grants_ai_process');
    }
    return 'スケジュールされていません';
}

/**
 * 統計情報を取得
 *
 * @param string $type 統計タイプ（sync, ai）
 * @return array 統計情報
 */
function auto_grants_get_stats($type) {
    $scheduler = auto_grants()->scheduler;
    if ($scheduler) {
        return $scheduler->get_stats($type);
    }
    return array();
}

/**
 * プラグインが有効かチェック
 *
 * @return bool 有効かどうか
 */
function auto_grants_is_plugin_active() {
    return class_exists('Auto_Grants') && Auto_Grants::get_instance() !== null;
}

/**
 * 必須プラグインが有効かチェック
 *
 * @return array チェック結果
 */
function auto_grants_check_required_plugins() {
    $results = array();

    // ACFのチェック
    $results['acf'] = array(
        'name'    => 'Advanced Custom Fields',
        'active'  => class_exists('acf'),
        'required' => false, // ACFは必須ではない
        'message' => 'カスタムフィールド管理に推奨されます',
    );

    return $results;
}

/**
 * 環境情報を取得
 *
 * @return array 環境情報
 */
function auto_grants_get_environment_info() {
    global $wp_version;

    return array(
        'php_version'     => PHP_VERSION,
        'wp_version'      => $wp_version,
        'plugin_version'  => AUTO_GRANTS_VERSION,
        'curl_available'  => function_exists('curl_version'),
        'json_available'  => function_exists('json_encode'),
        'ssl_available'   => extension_loaded('openssl'),
        'timezone'        => date_default_timezone_get(),
        'memory_limit'    => ini_get('memory_limit'),
        'max_execution_time' => ini_get('max_execution_time'),
        'log_directory'     => AUTO_GRANTS_LOG_DIR,
        'log_directory_writable' => is_writable(AUTO_GRANTS_LOG_DIR),
    );
}