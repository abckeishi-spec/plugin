<?php
/**
 * ACFフィールド統合クラス
 * 
 * @package Auto_Grants
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Auto_Grants_ACF クラス
 */
class Auto_Grants_ACF {

    /**
     * フィールドグループキー
     */
    const FIELD_GROUP_KEY = 'group_auto_grants_fields';

    /**
     * コンストラクタ
     */
    public function __construct() {
        $this->register_field_group();
    }

    /**
     * ACFフィールドグループを登録
     */
    private function register_field_group() {
        if (!function_exists('acf_add_local_field_group')) {
            return;
        }

        acf_add_local_field_group(array(
            'key'    => self::FIELD_GROUP_KEY,
            'title'  => '補助金詳細',
            'fields' => $this->get_fields(),
            'location' => array(
                array(
                    array(
                        'param'    => 'post_type',
                        'operator' => '==',
                        'value'    => AUTO_GRANTS_POST_TYPE,
                    ),
                ),
            ),
            'menu_order'            => 0,
            'position'              => 'normal',
            'style'                 => 'default',
            'label_placement'       => 'top',
            'instruction_placement' => 'label',
            'hide_on_screen'        => '',
            'active'                => true,
            'description'           => '補助金情報の詳細フィールド',
            'show_in_rest'          => true,
        ));
    }

    /**
     * フィールド定義を取得
     *
     * @return array フィールド定義
     */
    private function get_fields() {
        return array(
            // AIによる3行要約
            array(
                'key'               => 'field_auto_grants_ai_summary',
                'label'             => 'AIによる3行要約',
                'name'              => 'ai_summary',
                'type'              => 'wysiwyg',
                'instructions'      => 'AIが生成した補助金の要約を表示します。',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '',
                    'class' => '',
                    'id'    => '',
                ),
                'default_value'     => '',
                'tabs'              => 'visual',
                'toolbar'           => 'basic',
                'media_upload'      => 0,
                'delay'             => 0,
            ),

            // 最大金額（表示用）
            array(
                'key'               => 'field_auto_grants_max_amount',
                'label'             => '最大金額（表示用）',
                'name'              => 'max_amount',
                'type'              => 'text',
                'instructions'      => '例: 200万円, 50万円/人',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '50',
                    'class' => '',
                    'id'    => '',
                ),
                'default_value'     => '',
                'placeholder'       => '200万円',
                'prepend'           => '',
                'append'            => '',
                'maxlength'         => '',
            ),

            // 最大金額（数値）
            array(
                'key'               => 'field_auto_grants_max_amount_numeric',
                'label'             => '最大金額（数値）',
                'name'              => 'max_amount_numeric',
                'type'              => 'number',
                'instructions'      => '検索・ソート用の数値（円単位）',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '50',
                    'class' => '',
                    'id'    => '',
                ),
                'default_value'     => '',
                'placeholder'       => '2000000',
                'prepend'           => '',
                'append'            => '円',
                'min'               => 0,
                'max'               => '',
                'step'              => 1,
            ),

            // 締切日（ソート用）
            array(
                'key'               => 'field_auto_grants_deadline_date',
                'label'             => '締切日（ソート用）',
                'name'              => 'deadline_date',
                'type'              => 'date_picker',
                'instructions'      => '申込締切日',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '50',
                    'class' => '',
                    'id'    => '',
                ),
                'display_format'    => 'Y/m/d',
                'return_format'     => 'Ymd',
                'first_day'         => 1,
            ),

            // 締切（表示用テキスト）
            array(
                'key'               => 'field_auto_grants_deadline_text',
                'label'             => '締切（表示用テキスト）',
                'name'              => 'deadline_text',
                'type'              => 'text',
                'instructions'      => '例: 2024年12月27日, 通年',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '50',
                    'class' => '',
                    'id'    => '',
                ),
                'default_value'     => '',
                'placeholder'       => '2024年12月27日',
                'prepend'           => '',
                'append'            => '',
                'maxlength'         => '',
            ),

            // 公募ステータス
            array(
                'key'               => 'field_auto_grants_application_status',
                'label'             => '公募ステータス',
                'name'              => 'application_status',
                'type'              => 'select',
                'instructions'      => '申込受付状態',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '50',
                    'class' => '',
                    'id'    => '',
                ),
                'choices'           => array(
                    'open'     => '募集中',
                    'closed'   => '募集終了',
                    'upcoming' => '募集開始前',
                ),
                'default_value'     => 'open',
                'allow_null'        => 0,
                'multiple'          => 0,
                'ui'                => 1,
                'ajax'              => 0,
                'return_format'     => 'value',
                'placeholder'       => '',
            ),

            // 実施組織
            array(
                'key'               => 'field_auto_grants_organization',
                'label'             => '実施組織',
                'name'              => 'organization',
                'type'              => 'text',
                'instructions'      => '補助金を実施している組織名',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '50',
                    'class' => '',
                    'id'    => '',
                ),
                'default_value'     => '',
                'placeholder'       => '経済産業省',
                'prepend'           => '',
                'append'            => '',
                'maxlength'         => '',
            ),

            // 申請難易度
            array(
                'key'               => 'field_auto_grants_difficulty_level',
                'label'             => '申請難易度',
                'name'              => 'difficulty_level',
                'type'              => 'select',
                'instructions'      => '申請の難易度を評価',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '50',
                    'class' => '',
                    'id'    => '',
                ),
                'choices'           => array(
                    'easy'   => '易しい',
                    'medium' => '普通',
                    'hard'   => '難しい',
                ),
                'default_value'     => 'medium',
                'allow_null'        => 0,
                'multiple'          => 0,
                'ui'                => 1,
                'ajax'              => 0,
                'return_format'     => 'value',
                'placeholder'       => '',
            ),

            // 公式サイトURL
            array(
                'key'               => 'field_auto_grants_official_url',
                'label'             => '公式サイトURL',
                'name'              => 'official_url',
                'type'              => 'url',
                'instructions'      => '補助金の公式情報ページURL',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '',
                    'class' => '',
                    'id'    => '',
                ),
                'default_value'     => '',
                'placeholder'       => 'https://www.example.com',
            ),

            // 補助金ID（公式）
            array(
                'key'               => 'field_auto_grants_official_id',
                'label'             => '補助金ID（公式）',
                'name'              => 'official_id',
                'type'              => 'text',
                'instructions'      => 'JグランツAPIの補助金ID',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '50',
                    'class' => '',
                    'id'    => '',
                ),
                'default_value'     => '',
                'placeholder'       => '',
                'prepend'           => '',
                'append'            => '',
                'maxlength'         => '',
            ),

            // AI処理済みフラグ
            array(
                'key'               => 'field_auto_grants_ai_processed',
                'label'             => 'AI処理済み',
                'name'              => 'ai_processed',
                'type'              => 'true_false',
                'instructions'      => 'AIによる記事生成が完了したか',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '50',
                    'class' => '',
                    'id'    => '',
                ),
                'message'           => 'AI処理済み',
                'default_value'     => 0,
                'ui'                => 1,
                'ui_on_text'        => '',
                'ui_off_text'       => '',
            ),

            // AI処理日時
            array(
                'key'               => 'field_auto_grants_ai_processed_date',
                'label'             => 'AI処理日時',
                'name'              => 'ai_processed_date',
                'type'              => 'date_time_picker',
                'instructions'      => 'AI処理が完了した日時',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '50',
                    'class' => '',
                    'id'    => '',
                ),
                'display_format'    => 'Y-m-d H:i:s',
                'return_format'     => 'Y-m-d H:i:s',
                'first_day'         => 1,
            ),

            // 支援率
            array(
                'key'               => 'field_auto_grants_subsidy_rate',
                'label'             => '支援率',
                'name'              => 'subsidy_rate',
                'type'              => 'text',
                'instructions'      => '例: 3/4, 2/3, 1/2',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '50',
                    'class' => '',
                    'id'    => '',
                ),
                'default_value'     => '',
                'placeholder'       => '3/4',
                'prepend'           => '',
                'append'            => '',
                'maxlength'         => '',
            ),

            // 対象地域詳細
            array(
                'key'               => 'field_auto_grants_target_area_detail',
                'label'             => '対象地域詳細',
                'name'              => 'target_area_detail',
                'type'              => 'textarea',
                'instructions'      => '対象地域の詳細情報',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '',
                    'class' => '',
                    'id'    => '',
                ),
                'default_value'     => '',
                'placeholder'       => '',
                'maxlength'         => '',
                'rows'              => 3,
                'new_lines'         => '',
            ),

            // 申請開始日時
            array(
                'key'               => 'field_auto_grants_acceptance_start_datetime',
                'label'             => '申請開始日時',
                'name'              => 'acceptance_start_datetime',
                'type'              => 'text',
                'instructions'      => '申請受付開始日時',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '50',
                    'class' => '',
                    'id'    => '',
                ),
                'default_value'     => '',
                'placeholder'       => '2024-01-01 00:00:00',
                'prepend'           => '',
                'append'            => '',
                'maxlength'         => '',
            ),

            // 申請終了日時
            array(
                'key'               => 'field_auto_grants_acceptance_end_datetime',
                'label'             => '申請終了日時',
                'name'              => 'acceptance_end_datetime',
                'type'              => 'text',
                'instructions'      => '申請受付終了日時',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '50',
                    'class' => '',
                    'id'    => '',
                ),
                'default_value'     => '',
                'placeholder'       => '2024-12-31 23:59:59',
                'prepend'           => '',
                'append'            => '',
                'maxlength'         => '',
            ),

            // 生データ（JSON）
            array(
                'key'               => 'field_auto_grants_raw_data',
                'label'             => '生データ（JSON）',
                'name'              => 'raw_data',
                'type'              => 'textarea',
                'instructions'      => 'JグランツAPIから取得した生データ',
                'required'          => false,
                'conditional_logic' => 0,
                'wrapper'           => array(
                    'width' => '',
                    'class' => '',
                    'id'    => '',
                ),
                'default_value'     => '',
                'placeholder'       => '',
                'maxlength'         => '',
                'rows'              => 5,
                'new_lines'         => '',
            ),
        );
    }

    /**
     * ACFフィールドの値を取得
     *
     * @param string $field_name フィールド名
     * @param int    $post_id 投稿ID
     * @param mixed  $default デフォルト値
     * @return mixed フィールド値
     */
    public static function get_field_value($field_name, $post_id = null, $default = '') {
        if (!function_exists('get_field')) {
            return get_post_meta($post_id, $field_name, true) ?: $default;
        }

        $value = get_field($field_name, $post_id);
        return $value !== false && $value !== null && $value !== '' ? $value : $default;
    }

    /**
     * ACFフィールドの値を更新
     *
     * @param string $field_name フィールド名
     * @param mixed  $value 値
     * @param int    $post_id 投稿ID
     * @return bool 成功/失敗
     */
    public static function update_field_value($field_name, $value, $post_id) {
        if (!function_exists('update_field')) {
            return update_post_meta($post_id, $field_name, $value);
        }

        return update_field($field_name, $value, $post_id);
    }

    /**
     * フィールドグループが存在するかチェック
     *
     * @return bool
     */
    public static function field_group_exists() {
        if (!function_exists('acf_get_field_group')) {
            return false;
        }

        $field_group = acf_get_field_group(self::FIELD_GROUP_KEY);
        return !empty($field_group);
    }

    /**
     * ACFが有効かチェック
     *
     * @return bool
     */
    public static function is_acf_active() {
        return class_exists('acf') || function_exists('get_field');
    }

    /**
     * フィールドラベルを取得
     *
     * @param string $field_name フィールド名
     * @return string フィールドラベル
     */
    public static function get_field_label($field_name) {
        if (!function_exists('acf_get_field')) {
            // ACFが無効な場合のラベル
            $labels = array(
                'ai_summary'           => 'AIによる3行要約',
                'max_amount'           => '最大金額（表示用）',
                'max_amount_numeric'   => '最大金額（数値）',
                'deadline_date'        => '締切日（ソート用）',
                'deadline_text'      => '締切（表示用テキスト）',
                'application_status' => '公募ステータス',
                'organization'         => '実施組織',
                'difficulty_level'     => '申請難易度',
                'official_url'         => '公式サイトURL',
                'official_id'          => '補助金ID（公式）',
                'ai_processed'         => 'AI処理済み',
                'ai_processed_date'    => 'AI処理日時',
                'subsidy_rate'         => '支援率',
                'target_area_detail' => '対象地域詳細',
                'acceptance_start_datetime' => '申請開始日時',
                'acceptance_end_datetime'   => '申請終了日時',
                'raw_data'             => '生データ（JSON）',
            );
            return isset($labels[$field_name]) ? $labels[$field_name] : $field_name;
        }

        $field = acf_get_field($field_name);
        if ($field && isset($field['label'])) {
            return $field['label'];
        }

        return $field_name;
    }
}