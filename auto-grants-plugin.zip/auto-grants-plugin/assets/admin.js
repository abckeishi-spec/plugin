/**
 * Auto Grants 管理画面JavaScript
 */

(function($) {
    'use strict';

    /**
     * 手動同期実行
     */
    function performManualSync() {
        var $button = $('#manual-sync');
        var $result = $('#sync-result');

        // ボタンを無効化
        $button.prop('disabled', true).text('同期中...');
        $result.removeClass('error success').text('');

        $.ajax({
            url: auto_grants_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'auto_grants_manual_sync',
                nonce: auto_grants_ajax.nonce.manual_sync
            },
            success: function(response) {
                if (response.success) {
                    $result.addClass('success').text('同期完了: ' + response.data.message);
                    // ステータスを更新
                    updateStatus();
                } else {
                    $result.addClass('error').text('同期エラー: ' + response.data);
                }
            },
            error: function(xhr, status, error) {
                $result.addClass('error').text('通信エラー: ' + error);
            },
            complete: function() {
                // ボタンを再有効化
                $button.prop('disabled', false).text('今すぐ同期');
            }
        });
    }

    /**
     * 手動AI処理実行
     */
    function performManualAI() {
        var $button = $('#manual-ai');
        var $result = $('#ai-result');
        var batchSize = $('#batch-size').val();

        // ボタンを無効化
        $button.prop('disabled', true).text('処理中...');
        $result.removeClass('error success').text('');

        $.ajax({
            url: auto_grants_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'auto_grants_manual_ai',
                nonce: auto_grants_ajax.nonce.manual_ai,
                batch_size: batchSize
            },
            success: function(response) {
                if (response.success) {
                    var message = response.data.processed + '件処理完了';
                    if (response.data.errors > 0) {
                        message += '（' + response.data.errors + '件エラー）';
                    }
                    $result.addClass('success').text(message);
                    // ステータスを更新
                    updateStatus();
                } else {
                    $result.addClass('error').text('処理エラー: ' + response.data);
                }
            },
            error: function(xhr, status, error) {
                $result.addClass('error').text('通信エラー: ' + error);
            },
            complete: function() {
                // ボタンを再有効化
                $button.prop('disabled', false).text('AI処理実行');
            }
        });
    }

    /**
     * ステータス情報を更新
     */
    function updateStatus() {
        // 未処理下書き数を更新（実際にはAJAXで取得すべき）
        // ここでは簡易的に実装
        setTimeout(function() {
            // ページをリロードして最新情報を取得
            location.reload();
        }, 2000);
    }

    /**
     * 設定フォームのバリデーション
     */
    function validateSettingsForm() {
        var $form = $('#auto-grants-settings form');
        
        $form.on('submit', function(e) {
            var geminiKey = $('#auto_grants_gemini_api_key').val().trim();
            var apiEndpoint = $('#auto_grants_api_endpoint').val().trim();
            
            // APIエンドポイントの基本チェック
            if (apiEndpoint && !isValidUrl(apiEndpoint)) {
                e.preventDefault();
                alert('JグランツAPIエンドポイントが正しいURL形式ではありません。');
                $('#auto_grants_api_endpoint').focus();
                return false;
            }
            
            // Gemini APIキーの形式チェック
            if (geminiKey && !isValidGeminiKey(geminiKey)) {
                if (!confirm('Gemini APIキーの形式が正しくない可能性があります。保存しますか？')) {
                    e.preventDefault();
                    $('#auto_grants_gemini_api_key').focus();
                    return false;
                }
            }
        });
    }

    /**
     * URL形式をチェック
     */
    function isValidUrl(string) {
        try {
            new URL(string);
            return true;
        } catch (_) {
            return false;
        }
    }

    /**
     * Gemini APIキーの形式をチェック
     */
    function isValidGeminiKey(key) {
        // 簡易的な形式チェック
        return key.length >= 30 && /^[A-Za-z0-9_-]+$/.test(key);
    }

    /**
     * バッチサイズの変更
     */
    function handleBatchSizeChange() {
        $('#batch-size').on('change', function() {
            var size = $(this).val();
            auto_grants_debug_log('バッチサイズ変更', {size: size});
        });
    }

    /**
     * ログページの機能
     */
    function initLogsPage() {
        if (!$('#auto-grants-logs').length) {
            return;
        }

        // ログ更新ボタン
        $('#refresh-logs').on('click', function() {
            location.reload();
        });

        // ログクリアボタン
        $('#clear-logs').on('click', function() {
            if (confirm('本当にすべてのログをクリアしますか？')) {
                // AJAXでログクリアを実行（実装が必要）
                alert('ログクリア機能は現在開発中です。');
            }
        });

        // ログレベルによるフィルタリング
        $('.log-level-filter').on('change', function() {
            var level = $(this).val();
            filterLogsByLevel(level);
        });
    }

    /**
     * ログをレベルでフィルタリング
     */
    function filterLogsByLevel(level) {
        var $rows = $('#log-container tbody tr');
        
        if (level === 'all') {
            $rows.show();
        } else {
            $rows.each(function() {
                var $row = $(this);
                var rowLevel = $row.find('.log-level').text();
                if (rowLevel === level) {
                    $row.show();
                } else {
                    $row.hide();
                }
            });
        }
    }

    /**
     * 設定ページの機能
     */
    function initSettingsPage() {
        if (!$('#auto-grants-settings').length) {
            return;
        }

        // フォームバリデーション
        validateSettingsForm();

        // AIプロンプトのリセットボタン
        $('.reset-ai-prompt').on('click', function() {
            if (confirm('AIプロンプトをデフォルトにリセットしますか？')) {
                $('#auto_grants_ai_prompt').val(getDefaultAiPrompt());
            }
        });

        // 同期時刻の次回実行予定を表示
        updateNextSyncTime();
    }

    /**
     * デフォルトAIプロンプトを取得
     */
    function getDefaultAiPrompt() {
        return 'あなたは補助金申請の専門家です。以下の補助金情報を基に、申請者にとって有益な記事を作成してください。\n\n【記事作成ガイドライン】\n1. タイトルはSEOを意識し、補助金名＋「申請方法」や「利用方法」などのキーワードを含める\n2. 本文は以下の構成で書く：\n   - この補助金とは（3行程度）\n   - 対象者・条件\n   - 支援内容（金額、期間など）\n   - 申請方法と必要書類\n   - 申請のポイントと注意事項\n   - よくある質問\n3. 専門用語は避け、初心者にも分かりやすい言葉で説明する\n4. 申請締切が近い場合は、その旨を強調する\n5. 3行要約は、箇条書きで記事の要点を整理する\n\n【補助金情報】';
    }

    /**
     * 次回同期時刻を更新
     */
    function updateNextSyncTime() {
        // 実際にはAJAXで取得すべき
        var syncTime = $('#auto_grants_sync_time').val();
        var now = new Date();
        var nextSync = new Date();
        
        var timeParts = syncTime.split(':');
        nextSync.setHours(parseInt(timeParts[0]), parseInt(timeParts[1]), 0, 0);
        
        if (nextSync <= now) {
            nextSync.setDate(nextSync.getDate() + 1);
        }
        
        var formatted = nextSync.toLocaleString('ja-JP');
        $('#next-sync-time').text(formatted);
    }

    /**
     * 手動実行ページの機能
     */
    function initManualPage() {
        if (!$('#auto-grants-manual').length) {
            return;
        }

        // 手動同期ボタン
        $('#manual-sync').on('click', performManualSync);

        // 手動AI処理ボタン
        $('#manual-ai').on('click', performManualAI);

        // バッチサイズ変更
        handleBatchSizeChange();

        // 定期的にステータスを更新（30秒ごと）
        setInterval(function() {
            // 実装によりますが、AJAXで最新情報を取得
        }, 30000);
    }

    /**
     * カスタムカラムの機能
     */
    function initCustomColumns() {
        // ステータスラベルの色付け
        $('.grant-status').each(function() {
            var $this = $(this);
            var status = $this.text();
            
            if (status === '募集中') {
                $this.addClass('status-open');
            } else if (status === '募集終了') {
                $this.addClass('status-closed');
            } else if (status === '募集開始前') {
                $this.addClass('status-upcoming');
            }
        });

        // AI処理ステータスの色付け
        $('.ai-status').each(function() {
            var $this = $(this);
            var status = $this.text();
            
            if (status === '✅ 完了') {
                $this.addClass('ai-complete');
            } else if (status === '⏳ 未処理') {
                $this.addClass('ai-pending');
            }
        });
    }

    /**
     * ドキュメント準備完了
     */
    $(document).ready(function() {
        // 各ページの初期化
        initSettingsPage();
        initManualPage();
        initLogsPage();
        initCustomColumns();

        // 共通機能
        handleBatchSizeChange();

        auto_grants_debug_log('Auto Grants 管理画面 JavaScript 初期化完了');
    });

})(jQuery);